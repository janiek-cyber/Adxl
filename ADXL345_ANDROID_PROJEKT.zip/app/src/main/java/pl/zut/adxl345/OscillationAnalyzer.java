package pl.zut.adxl345;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Pomiar częstotliwości i skoku oscylacji z 3-osiowego akcelerometru.
 * Wejście: przyspieszenie w g i rzeczywiste znaczniki czasu.
 * Metoda: detrend -> PCA (power iteration) -> wyszukiwanie częstotliwości
 * -> dopasowanie sin/cos -> skok P-P = 2*a_peak/(2*pi*f)^2.
 */
final class OscillationAnalyzer {
    static final double G0 = 9.80665;
    static final int MIN_SAMPLES = 40;

    static final class Sample {
        final double t;
        final double x;
        final double y;
        final double z;

        Sample(double t, double x, double y, double z) {
            this.t = t;
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    static final class Result {
        final double frequencyHz;
        final double accelPeakG;
        final double amplitudeMm;
        final double strokePpMm;
        final double qualityPct;
        final double sampleRateHz;
        final double dirX;
        final double dirY;
        final double dirZ;

        Result(double frequencyHz, double accelPeakG, double amplitudeMm,
               double strokePpMm, double qualityPct, double sampleRateHz,
               double dirX, double dirY, double dirZ) {
            this.frequencyHz = frequencyHz;
            this.accelPeakG = accelPeakG;
            this.amplitudeMm = amplitudeMm;
            this.strokePpMm = strokePpMm;
            this.qualityPct = qualityPct;
            this.sampleRateHz = sampleRateHz;
            this.dirX = dirX;
            this.dirY = dirY;
            this.dirZ = dirZ;
        }
    }

    private static final class Fit {
        final double sse;
        final double[] coef;
        Fit(double sse, double[] coef) {
            this.sse = sse;
            this.coef = coef;
        }
    }

    static Result analyze(List<Sample> input, double fMinHz, double fMaxHz) {
        if (input == null || input.size() < MIN_SAMPLES) return null;

        ArrayList<Sample> samples = new ArrayList<>(input.size());
        for (Sample s : input) {
            if (s != null && finite(s.t) && finite(s.x) && finite(s.y) && finite(s.z)) {
                samples.add(s);
            }
        }
        if (samples.size() < MIN_SAMPLES) return null;
        samples.sort((a, b) -> Double.compare(a.t, b.t));

        int n = samples.size();
        double t0 = samples.get(0).t;
        double t1 = samples.get(n - 1).t;
        double duration = t1 - t0;
        if (!(duration > 0.0)) return null;

        ArrayList<Double> dts = new ArrayList<>();
        for (int i = 1; i < n; i++) {
            double dt = samples.get(i).t - samples.get(i - 1).t;
            if (dt > 1e-6 && finite(dt)) dts.add(dt);
        }
        if (dts.size() < MIN_SAMPLES / 2) return null;
        Collections.sort(dts);
        double medianDt = dts.get(dts.size() / 2);
        if (!(medianDt > 0.0)) return null;
        double fs = 1.0 / medianDt;

        double[] t = new double[n];
        double[][] xyz = new double[n][3];
        double meanT = 0.0;
        for (int i = 0; i < n; i++) {
            Sample s = samples.get(i);
            t[i] = s.t;
            xyz[i][0] = s.x;
            xyz[i][1] = s.y;
            xyz[i][2] = s.z;
            meanT += s.t;
        }
        meanT /= n;

        // Detrend liniowy każdej osi.
        double[][] d = new double[n][3];
        for (int axis = 0; axis < 3; axis++) {
            double sy = 0.0, st = 0.0, stt = 0.0, sty = 0.0;
            for (int i = 0; i < n; i++) {
                double tc = t[i] - meanT;
                double y = xyz[i][axis];
                sy += y;
                st += tc;
                stt += tc * tc;
                sty += tc * y;
            }
            double denom = n * stt - st * st;
            double slope = Math.abs(denom) < 1e-18 ? 0.0 : (n * sty - st * sy) / denom;
            double intercept = (sy - slope * st) / n;
            for (int i = 0; i < n; i++) {
                double tc = t[i] - meanT;
                d[i][axis] = xyz[i][axis] - (intercept + slope * tc);
            }
        }

        // Macierz kowariancji 3x3.
        double[][] cov = new double[3][3];
        for (int i = 0; i < n; i++) {
            for (int a = 0; a < 3; a++) {
                for (int b = 0; b < 3; b++) cov[a][b] += d[i][a] * d[i][b];
            }
        }
        double div = Math.max(1, n - 1);
        for (int a = 0; a < 3; a++) for (int b = 0; b < 3; b++) cov[a][b] /= div;

        // Dominujący wektor własny przez power iteration.
        double[] dir = {1.0, 1.0, 1.0};
        normalize3(dir);
        for (int it = 0; it < 40; it++) {
            double[] v = {
                    cov[0][0] * dir[0] + cov[0][1] * dir[1] + cov[0][2] * dir[2],
                    cov[1][0] * dir[0] + cov[1][1] * dir[1] + cov[1][2] * dir[2],
                    cov[2][0] * dir[0] + cov[2][1] * dir[1] + cov[2][2] * dir[2]
            };
            if (norm3(v) < 1e-15) return null;
            normalize3(v);
            dir = v;
        }

        double[] y = new double[n];
        double meanY = 0.0;
        for (int i = 0; i < n; i++) {
            y[i] = d[i][0] * dir[0] + d[i][1] * dir[1] + d[i][2] * dir[2];
            meanY += y[i];
        }
        meanY /= n;
        double sumSq = 0.0;
        for (int i = 0; i < n; i++) {
            y[i] -= meanY;
            sumSq += y[i] * y[i];
        }
        double rms = Math.sqrt(sumSq / n);
        if (!finite(rms) || rms < 0.002) return null;

        double fMin = Math.max(fMinHz, 2.0 / duration); // co najmniej 2 pełne cykle
        double fMax = Math.min(fMaxHz, 0.45 * fs);
        if (!(fMax > fMin) || fMin <= 0.0) return null;

        // Szybki skan częstotliwości na rzeczywistych znacznikach czasu.
        double coarseStep = Math.max(0.03, 1.0 / (duration * 6.0));
        int coarseCount = (int) Math.ceil((fMax - fMin) / coarseStep) + 1;
        if (coarseCount > 1800) {
            coarseStep = (fMax - fMin) / 1799.0;
            coarseCount = 1800;
        }
        double bestF = fMin;
        double bestPower = -1.0;
        for (int k = 0; k < coarseCount; k++) {
            double f = Math.min(fMax, fMin + k * coarseStep);
            double omega = 2.0 * Math.PI * f;
            double ss = 0.0, cc = 0.0, ys = 0.0, yc = 0.0;
            for (int i = 0; i < n; i++) {
                double ph = omega * (t[i] - t0);
                double s = Math.sin(ph), c = Math.cos(ph);
                ss += s * s;
                cc += c * c;
                ys += y[i] * s;
                yc += y[i] * c;
            }
            double power = (ys * ys) / Math.max(ss, 1e-12) + (yc * yc) / Math.max(cc, 1e-12);
            if (power > bestPower) {
                bestPower = power;
                bestF = f;
            }
        }

        Fit bestFit = null;
        double half = coarseStep;
        for (int pass = 0; pass < 3; pass++) {
            double lo = Math.max(fMin, bestF - half);
            double hi = Math.min(fMax, bestF + half);
            for (int k = 0; k <= 20; k++) {
                double f = lo + (hi - lo) * k / 20.0;
                Fit fit = fitSineTrend(t, y, meanT, t0, f);
                if (fit != null && (bestFit == null || fit.sse < bestFit.sse)) {
                    bestFit = fit;
                    bestF = f;
                }
            }
            half = Math.max(half / 8.0, 1e-5);
        }
        if (bestFit == null || !(bestF > 0.0)) return null;

        double accelPeakG = Math.hypot(bestFit.coef[0], bestFit.coef[1]);
        if (!finite(accelPeakG) || accelPeakG < 0.002) return null;

        double sst = 0.0;
        for (double v : y) sst += v * v;
        double r2 = sst <= 1e-18 ? 0.0 : 1.0 - bestFit.sse / sst;
        double quality = Math.max(0.0, Math.min(100.0, 100.0 * r2));

        double omega = 2.0 * Math.PI * bestF;
        double amplitudeMm = (accelPeakG * G0) / (omega * omega) * 1000.0;
        double strokePpMm = 2.0 * amplitudeMm;
        if (!finite(amplitudeMm) || !finite(strokePpMm)) return null;

        return new Result(bestF, accelPeakG, amplitudeMm, strokePpMm,
                quality, fs, dir[0], dir[1], dir[2]);
    }

    private static Fit fitSineTrend(double[] t, double[] y, double meanT, double t0, double f) {
        int n = t.length;
        double[][] a = new double[4][4];
        double[] b = new double[4];
        double omega = 2.0 * Math.PI * f;
        for (int i = 0; i < n; i++) {
            double ph = omega * (t[i] - t0);
            double[] v = {Math.sin(ph), Math.cos(ph), 1.0, t[i] - meanT};
            for (int r = 0; r < 4; r++) {
                b[r] += v[r] * y[i];
                for (int c = 0; c < 4; c++) a[r][c] += v[r] * v[c];
            }
        }
        double[] coef = solve4(a, b);
        if (coef == null) return null;
        double sse = 0.0;
        for (int i = 0; i < n; i++) {
            double ph = omega * (t[i] - t0);
            double pred = coef[0] * Math.sin(ph) + coef[1] * Math.cos(ph)
                    + coef[2] + coef[3] * (t[i] - meanT);
            double e = y[i] - pred;
            sse += e * e;
        }
        return new Fit(sse, coef);
    }

    private static double[] solve4(double[][] aIn, double[] bIn) {
        double[][] m = new double[4][5];
        for (int r = 0; r < 4; r++) {
            System.arraycopy(aIn[r], 0, m[r], 0, 4);
            m[r][4] = bIn[r];
        }
        for (int col = 0; col < 4; col++) {
            int pivot = col;
            for (int r = col + 1; r < 4; r++) {
                if (Math.abs(m[r][col]) > Math.abs(m[pivot][col])) pivot = r;
            }
            if (Math.abs(m[pivot][col]) < 1e-14) return null;
            if (pivot != col) {
                double[] tmp = m[pivot];
                m[pivot] = m[col];
                m[col] = tmp;
            }
            double div = m[col][col];
            for (int c = col; c < 5; c++) m[col][c] /= div;
            for (int r = 0; r < 4; r++) {
                if (r == col) continue;
                double factor = m[r][col];
                for (int c = col; c < 5; c++) m[r][c] -= factor * m[col][c];
            }
        }
        return new double[]{m[0][4], m[1][4], m[2][4], m[3][4]};
    }

    private static boolean finite(double v) {
        return !Double.isNaN(v) && !Double.isInfinite(v);
    }

    private static double norm3(double[] v) {
        return Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    }

    private static void normalize3(double[] v) {
        double n = norm3(v);
        if (n <= 0.0) return;
        v[0] /= n; v[1] /= n; v[2] /= n;
    }
}

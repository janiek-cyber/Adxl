package pl.zut.adxl345;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Minimalny generator XLSX bez ciężkich bibliotek typu Apache POI. */
final class XlsxExporter {
    private static final int EXCEL_MAX_ROWS = 1_048_576;

    static void write(OutputStream target, File csvFile, SessionRecorder.Stats stats) throws IOException {
        try (ZipOutputStream zip = new ZipOutputStream(target, StandardCharsets.UTF_8)) {
            text(zip, "[Content_Types].xml", contentTypes());
            text(zip, "_rels/.rels", rootRels());
            text(zip, "docProps/app.xml", appProps());
            text(zip, "docProps/core.xml", coreProps());
            text(zip, "xl/workbook.xml", workbook());
            text(zip, "xl/_rels/workbook.xml.rels", workbookRels());
            text(zip, "xl/styles.xml", styles());
            summarySheet(zip, stats);
            dataSheet(zip, csvFile);
        }
    }

    private static void summarySheet(ZipOutputStream zip, SessionRecorder.Stats s) throws IOException {
        zip.putNextEntry(new ZipEntry("xl/worksheets/sheet1.xml"));
        OutputStreamWriter w = new OutputStreamWriter(zip, StandardCharsets.UTF_8);
        w.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        w.write("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");
        row(w, 1, new Cell[]{str("Parametr", true), str("Wartość", true), str("Uwagi", true)});
        int r = 2;
        r = summaryRow(w, r, "Liczba zapisanych próbek", (double) s.rows, "wiersze danych");
        r = summaryRow(w, r, "Liczba wiarygodnych wyników skoku", (double) s.validStrokeCount, "jakość >= 50%");
        r = summaryRow(w, r, "Średni SKOK P-P", s.meanStroke(), "mm; jakość >= 50%");
        r = summaryRow(w, r, "Minimalny SKOK P-P", s.strokeMin, "mm; jakość >= 50%");
        r = summaryRow(w, r, "Maksymalny SKOK P-P", s.strokeMax, "mm; jakość >= 50%");
        r = summaryRow(w, r, "Ostatni SKOK P-P", s.lastStroke, "mm; jakość >= 50%");
        r = summaryRow(w, r, "Średnia częstotliwość", s.meanFreq(), "Hz; jakość >= 50%");
        r = summaryRow(w, r, "Średnia jakość", s.meanQuality(), "%");
        r = summaryText(w, r, "Metoda", "PCA + dopasowanie sinusoidy", "Skok P-P = 2*a_peak/(2*pi*f)^2");
        summaryText(w, r, "Uwaga", "Pomiar dla ruchu okresowego / oscylacyjnego", "Nie jest to pomiar absolutnej drogi ruchu nieokresowego.");
        w.write("</sheetData></worksheet>");
        w.flush();
        zip.closeEntry();
    }

    private static int summaryRow(OutputStreamWriter w, int r, String name, Double value, String note) throws IOException {
        row(w, r, new Cell[]{str(name, false), value == null ? str("", false) : num(value), str(note, false)});
        return r + 1;
    }

    private static int summaryText(OutputStreamWriter w, int r, String name, String value, String note) throws IOException {
        row(w, r, new Cell[]{str(name, false), str(value, false), str(note, false)});
        return r + 1;
    }

    private static void dataSheet(ZipOutputStream zip, File csvFile) throws IOException {
        zip.putNextEntry(new ZipEntry("xl/worksheets/sheet2.xml"));
        OutputStreamWriter w = new OutputStreamWriter(zip, StandardCharsets.UTF_8);
        w.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        w.write("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
        w.write("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><sheetData>");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(csvFile), StandardCharsets.UTF_8))) {
            String line;
            int r = 1;
            while ((line = br.readLine()) != null && r <= EXCEL_MAX_ROWS) {
                if (r == 1 && line.startsWith("\uFEFF")) line = line.substring(1);
                String[] p = line.split(";", -1);
                Cell[] cells = new Cell[p.length];
                for (int c = 0; c < p.length; c++) {
                    if (r == 1 || c == 0 || p[c].isEmpty()) cells[c] = str(p[c], r == 1);
                    else {
                        try { cells[c] = num(Double.parseDouble(p[c])); }
                        catch (NumberFormatException e) { cells[c] = str(p[c], false); }
                    }
                }
                row(w, r, cells);
                r++;
            }
        }
        w.write("</sheetData></worksheet>");
        w.flush();
        zip.closeEntry();
    }

    private static final class Cell {
        final boolean numeric;
        final String value;
        final boolean header;
        Cell(boolean numeric, String value, boolean header) { this.numeric = numeric; this.value = value; this.header = header; }
    }

    private static Cell str(String s, boolean header) { return new Cell(false, s == null ? "" : s, header); }
    private static Cell num(double v) { return new Cell(true, String.format(Locale.US, "%.10g", v), false); }

    private static void row(OutputStreamWriter w, int r, Cell[] cells) throws IOException {
        w.write("<row r=\""); w.write(Integer.toString(r)); w.write("\">");
        for (int c = 0; c < cells.length; c++) {
            Cell cell = cells[c];
            String ref = col(c + 1) + r;
            if (cell.numeric) {
                w.write("<c r=\""); w.write(ref); w.write("\"><v>"); w.write(cell.value); w.write("</v></c>");
            } else {
                w.write("<c r=\""); w.write(ref); w.write("\" t=\"inlineStr\"");
                if (cell.header) w.write(" s=\"1\"");
                w.write("><is><t xml:space=\"preserve\">"); w.write(xml(cell.value)); w.write("</t></is></c>");
            }
        }
        w.write("</row>");
    }

    private static String col(int index) {
        StringBuilder s = new StringBuilder();
        int n = index;
        while (n > 0) {
            n--;
            s.insert(0, (char) ('A' + (n % 26)));
            n /= 26;
        }
        return s.toString();
    }

    private static void text(ZipOutputStream zip, String path, String value) throws IOException {
        zip.putNextEntry(new ZipEntry(path));
        zip.write(value.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private static String xml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");
    }

    private static String contentTypes() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>" +
                "<Override PartName=\"/docProps/app.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.extended-properties+xml\"/>" +
                "</Types>";
    }

    private static String rootRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>" +
                "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties\" Target=\"docProps/app.xml\"/>" +
                "</Relationships>";
    }

    private static String workbook() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                "<sheets><sheet name=\"Podsumowanie\" sheetId=\"1\" r:id=\"rId1\"/>" +
                "<sheet name=\"Dane_1\" sheetId=\"2\" r:id=\"rId2\"/></sheets></workbook>";
    }

    private static String workbookRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet2.xml\"/>" +
                "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
                "</Relationships>";
    }

    private static String styles() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
                "<fills count=\"1\"><fill><patternFill patternType=\"none\"/></fill></fills>" +
                "<borders count=\"1\"><border/></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs>" +
                "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>";
    }

    private static String coreProps() {
        String now = OffsetDateTime.now().toString();
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
                "<dc:creator>ADXL345 Skok Android</dc:creator><cp:lastModifiedBy>ADXL345 Skok Android</cp:lastModifiedBy>" +
                "<dcterms:created xsi:type=\"dcterms:W3CDTF\">" + xml(now) + "</dcterms:created></cp:coreProperties>";
    }

    private static String appProps() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Properties xmlns=\"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties\" xmlns:vt=\"http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes\">" +
                "<Application>ADXL345 Skok Android</Application></Properties>";
    }
}

package pl.zut.adxl345;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

final class SessionRecorder {
    static final class DataRow {
        String timeIso;
        double timeFromTrigger;
        double x, y, z, mag, delta;
        OscillationAnalyzer.Result osc;
    }

    static final class Stats {
        long rows = 0;
        long validStrokeCount = 0;
        double strokeSum = 0.0;
        Double strokeMin = null;
        Double strokeMax = null;
        Double lastStroke = null;
        double freqSum = 0.0;
        double qualitySum = 0.0;

        void add(DataRow row) {
            rows++;
            if (row.osc != null && row.osc.qualityPct >= 50.0
                    && Double.isFinite(row.osc.strokePpMm)) {
                double s = row.osc.strokePpMm;
                validStrokeCount++;
                strokeSum += s;
                strokeMin = strokeMin == null ? s : Math.min(strokeMin, s);
                strokeMax = strokeMax == null ? s : Math.max(strokeMax, s);
                lastStroke = s;
                freqSum += row.osc.frequencyHz;
                qualitySum += row.osc.qualityPct;
            }
        }

        Double meanStroke() { return validStrokeCount == 0 ? null : strokeSum / validStrokeCount; }
        Double meanFreq() { return validStrokeCount == 0 ? null : freqSum / validStrokeCount; }
        Double meanQuality() { return validStrokeCount == 0 ? null : qualitySum / validStrokeCount; }
    }

    static final class ExportResult {
        final String csvLocation;
        final String xlsxLocation;
        ExportResult(String csvLocation, String xlsxLocation) {
            this.csvLocation = csvLocation;
            this.xlsxLocation = xlsxLocation;
        }
    }

    private final Context context;
    private final Stats stats = new Stats();
    private File tempCsv;
    private BufferedWriter writer;
    private String baseName;

    SessionRecorder(Context context) {
        this.context = context.getApplicationContext();
    }

    Stats getStats() { return stats; }

    void start(String baseName) throws IOException {
        this.baseName = baseName;
        tempCsv = new File(context.getCacheDir(), baseName + ".csv");
        writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tempCsv), StandardCharsets.UTF_8));
        writer.write('\uFEFF');
        writer.write("czas_iso;czas_od_startu_s;X_g;Y_g;Z_g;modul_g;delta_od_spoczynku_g;czestotliwosc_Hz;amplituda_przyspieszenia_g;amplituda_przemieszczenia_mm;skok_PP_mm;jakosc_proc;probkowanie_Hz\n");
    }

    boolean isStarted() { return writer != null; }

    void write(DataRow row) throws IOException {
        if (writer == null) return;
        OscillationAnalyzer.Result o = row.osc;
        writer.write(s(row.timeIso)); writer.write(';');
        writer.write(f(row.timeFromTrigger)); writer.write(';');
        writer.write(f(row.x)); writer.write(';');
        writer.write(f(row.y)); writer.write(';');
        writer.write(f(row.z)); writer.write(';');
        writer.write(f(row.mag)); writer.write(';');
        writer.write(f(row.delta)); writer.write(';');
        writer.write(o == null ? "" : f(o.frequencyHz)); writer.write(';');
        writer.write(o == null ? "" : f(o.accelPeakG)); writer.write(';');
        writer.write(o == null ? "" : f(o.amplitudeMm)); writer.write(';');
        writer.write(o == null ? "" : f(o.strokePpMm)); writer.write(';');
        writer.write(o == null ? "" : String.format(Locale.US, "%.3f", o.qualityPct)); writer.write(';');
        writer.write(o == null ? "" : String.format(Locale.US, "%.3f", o.sampleRateHz));
        writer.write('\n');
        stats.add(row);
        if (stats.rows % 100 == 0) writer.flush();
    }

    ExportResult finishAndExport() throws IOException {
        if (writer == null || tempCsv == null) return null;
        writer.flush();
        writer.close();
        writer = null;

        String csvName = baseName + ".csv";
        String xlsxName = baseName + ".xlsx";
        String csvLocation;
        String xlsxLocation;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            csvLocation = exportMediaStore(csvName, "text/csv", out -> copy(tempCsv, out));
            xlsxLocation = exportMediaStore(xlsxName,
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    out -> XlsxExporter.write(out, tempCsv, stats));
        } else {
            File root = new File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "ADXL345");
            if (!root.exists() && !root.mkdirs()) throw new IOException("Nie można utworzyć folderu: " + root);
            File csv = new File(root, csvName);
            File xlsx = new File(root, xlsxName);
            try (OutputStream out = new FileOutputStream(csv)) { copy(tempCsv, out); }
            try (OutputStream out = new FileOutputStream(xlsx)) { XlsxExporter.write(out, tempCsv, stats); }
            csvLocation = csv.getAbsolutePath();
            xlsxLocation = xlsx.getAbsolutePath();
        }

        //noinspection ResultOfMethodCallIgnored
        tempCsv.delete();
        tempCsv = null;
        return new ExportResult(csvLocation, xlsxLocation);
    }

    void abort() {
        try { if (writer != null) writer.close(); } catch (Exception ignored) {}
        writer = null;
        if (tempCsv != null) {
            //noinspection ResultOfMethodCallIgnored
            tempCsv.delete();
        }
        tempCsv = null;
    }

    private interface StreamWriter { void write(OutputStream out) throws IOException; }

    private String exportMediaStore(String displayName, String mime, StreamWriter streamWriter) throws IOException {
        ContentResolver resolver = context.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName);
        values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOCUMENTS + "/ADXL345");
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Uri uri = resolver.insert(collection, values);
        if (uri == null) throw new IOException("Nie można utworzyć pliku " + displayName);
        try {
            try (OutputStream out = resolver.openOutputStream(uri, "w")) {
                if (out == null) throw new IOException("Nie można otworzyć pliku " + displayName);
                streamWriter.write(out);
            }
            ContentValues ready = new ContentValues();
            ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
            resolver.update(uri, ready, null, null);
        } catch (IOException e) {
            resolver.delete(uri, null, null);
            throw e;
        }
        return Environment.DIRECTORY_DOCUMENTS + "/ADXL345/" + displayName;
    }

    private static void copy(File src, OutputStream out) throws IOException {
        try (FileInputStream in = new FileInputStream(src)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
        }
    }

    private static String s(String value) {
        return value == null ? "" : value.replace(";", ",").replace("\n", " ").replace("\r", " ");
    }

    private static String f(double v) {
        return String.format(Locale.US, "%.6f", v);
    }
}

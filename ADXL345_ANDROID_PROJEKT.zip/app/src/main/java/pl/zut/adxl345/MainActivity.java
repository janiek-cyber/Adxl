package pl.zut.adxl345;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;
import com.hoho.android.usbserial.util.SerialInputOutputManager;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity implements SerialInputOutputManager.Listener {
    private static final String ACTION_USB_PERMISSION = "pl.zut.adxl345.USB_PERMISSION";
    private static final double CALIBRATION_SECONDS = 2.0;
    private static final int MIN_CALIBRATION_SAMPLES = 20;
    private static final double KALMAN_Q = 0.001;
    private static final double KALMAN_R = 0.01;
    private static final double OSC_UPDATE_SECONDS = 0.5;
    private static final double UI_UPDATE_SECONDS = 0.08;

    private static final String NUMBER = "[-+]?(?:\\d+(?:[.,]\\d*)?|[.,]\\d+)(?:[eE][-+]?\\d+)?";
    private static final Pattern XYZ_PATTERN = Pattern.compile(
            "[Xx]\\s*[:=]\\s*(" + NUMBER + ").*?" +
            "[Yy]\\s*[:=]\\s*(" + NUMBER + ").*?" +
            "[Zz]\\s*[:=]\\s*(" + NUMBER + ")");

    private UsbManager usbManager;
    private final List<PortEntry> portEntries = new ArrayList<>();
    private UsbSerialPort serialPort;
    private UsbDeviceConnection usbConnection;
    private SerialInputOutputManager ioManager;
    private PortEntry pendingPermissionEntry;
    private boolean connected = false;

    private Spinner deviceSpinner, baudSpinner;
    private Button refreshButton, connectButton, startButton, stopButton;
    private EditText thresholdEdit, scaleEdit, pretriggerEdit, fminEdit, fmaxEdit, windowEdit;
    private CheckBox kalmanCheck, autoGCheck;
    private TextView statusText, currentValues, frequencyText, accelText, strokeText, qualityText, fileText, statsText;
    private SimpleLineChartView chart;

    private final Object stateLock = new Object();
    private boolean sessionActive = false;
    private boolean calibrating = false;
    private double calibrationStartSec = -1;
    private final ArrayList<double[]> calibrationSamples = new ArrayList<>();
    private double autoScaleFactor = 1.0;
    private double[] reference = null;
    private int motionHits = 0;
    private boolean triggered = false;
    private double recordStartSec = 0.0;
    private double plotStartSec = -1;
    private long sampleCount = 0;
    private long badLineCount = 0;
    private volatile Settings activeSettings = null;
    private volatile boolean kalmanEnabled = true;
    private volatile boolean autoGEnabled = true;
    private double lastUiSec = 0;
    private double lastOscScheduleSec = 0;

    private Kalman1D kx = new Kalman1D(KALMAN_Q, KALMAN_R);
    private Kalman1D ky = new Kalman1D(KALMAN_Q, KALMAN_R);
    private Kalman1D kz = new Kalman1D(KALMAN_Q, KALMAN_R);

    private final ArrayDeque<OscillationAnalyzer.Sample> oscBuffer = new ArrayDeque<>();
    private final ArrayDeque<TimedRow> preBuffer = new ArrayDeque<>();
    private volatile OscillationAnalyzer.Result currentOsc = null;
    private SessionRecorder recorder = null;

    private final ExecutorService analysisExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService exportExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean analysisRunning = new AtomicBoolean(false);
    private final StringBuilder serialTextBuffer = new StringBuilder();

    private final DateTimeFormatter fileStamp = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS", Locale.US);
    private final DateTimeFormatter isoStamp = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US);

    private final BroadcastReceiver permissionReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!ACTION_USB_PERMISSION.equals(intent.getAction())) return;
            PortEntry entry = pendingPermissionEntry;
            pendingPermissionEntry = null;
            boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
            if (granted && entry != null) openPort(entry);
            else setStatus("Brak zgody Androida na dostęp do urządzenia USB.");
        }
    };

    private static final class PortEntry {
        final UsbSerialDriver driver;
        final int portIndex;
        final String label;
        PortEntry(UsbSerialDriver driver, int portIndex, String label) {
            this.driver = driver; this.portIndex = portIndex; this.label = label;
        }
        @Override public String toString() { return label; }
    }

    private static final class Settings {
        final double threshold, scale, pretrigger, fmin, fmax, window;
        Settings(double threshold, double scale, double pretrigger, double fmin, double fmax, double window) {
            this.threshold=threshold; this.scale=scale; this.pretrigger=pretrigger;
            this.fmin=fmin; this.fmax=fmax; this.window=window;
        }
    }

    private static final class TimedRow {
        final double perfSec;
        final SessionRecorder.DataRow row;
        TimedRow(double perfSec, SessionRecorder.DataRow row) { this.perfSec=perfSec; this.row=row; }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        bindViews();
        setupUi();

        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(permissionReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(permissionReceiver, filter);
        }
        refreshDevices();
    }

    private void bindViews() {
        deviceSpinner=findViewById(R.id.deviceSpinner); baudSpinner=findViewById(R.id.baudSpinner);
        refreshButton=findViewById(R.id.refreshButton); connectButton=findViewById(R.id.connectButton);
        startButton=findViewById(R.id.startButton); stopButton=findViewById(R.id.stopButton);
        thresholdEdit=findViewById(R.id.thresholdEdit); scaleEdit=findViewById(R.id.scaleEdit);
        pretriggerEdit=findViewById(R.id.pretriggerEdit); fminEdit=findViewById(R.id.fminEdit);
        fmaxEdit=findViewById(R.id.fmaxEdit); windowEdit=findViewById(R.id.windowEdit);
        kalmanCheck=findViewById(R.id.kalmanCheck); autoGCheck=findViewById(R.id.autoGCheck);
        statusText=findViewById(R.id.statusText); currentValues=findViewById(R.id.currentValues);
        frequencyText=findViewById(R.id.frequencyText); accelText=findViewById(R.id.accelText);
        strokeText=findViewById(R.id.strokeText); qualityText=findViewById(R.id.qualityText);
        fileText=findViewById(R.id.fileText); statsText=findViewById(R.id.statsText);
        chart=findViewById(R.id.chart);
    }

    private void setupUi() {
        String[] bauds={"9600","19200","38400","57600","115200","230400","460800","921600"};
        ArrayAdapter<String> baudAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,bauds);
        baudAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        baudSpinner.setAdapter(baudAdapter); baudSpinner.setSelection(4);
        refreshButton.setOnClickListener(v->refreshDevices());
        connectButton.setOnClickListener(v->{ if(connected) disconnect(true); else connectSelected(); });
        startButton.setOnClickListener(v->startMeasurement());
        stopButton.setOnClickListener(v->stopMeasurement(true));
    }

    private void refreshDevices() {
        if (connected) return;
        portEntries.clear();
        List<UsbSerialDriver> drivers=UsbSerialProber.getDefaultProber().findAllDrivers(usbManager);
        for(UsbSerialDriver d:drivers){
            UsbDevice dev=d.getDevice();
            String base=String.format(Locale.US,"%s VID:%04X PID:%04X",
                    d.getClass().getSimpleName().replace("SerialDriver",""), dev.getVendorId(),dev.getProductId());
            for(int p=0;p<d.getPorts().size();p++) portEntries.add(new PortEntry(d,p,base+" / port "+p));
        }
        ArrayList<String> labels=new ArrayList<>();
        for(PortEntry e:portEntries) labels.add(e.label);
        if(labels.isEmpty()) labels.add("Brak obsługiwanego urządzenia USB");
        ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,labels);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        deviceSpinner.setAdapter(a);
        setStatus(portEntries.isEmpty()?"Nie znaleziono urządzenia USB-Serial. Podłącz przez USB-OTG i kliknij Odśwież.":"Znaleziono urządzenie. Wybierz port i kliknij Połącz.");
    }

    private void connectSelected() {
        int idx=deviceSpinner.getSelectedItemPosition();
        if(idx<0||idx>=portEntries.size()) { toast("Brak urządzenia USB-Serial."); return; }
        PortEntry e=portEntries.get(idx);
        UsbDevice dev=e.driver.getDevice();
        if(!usbManager.hasPermission(dev)){
            pendingPermissionEntry=e;
            Intent intent=new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName());
            int flags=PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_MUTABLE;
            PendingIntent pi=PendingIntent.getBroadcast(this,0,intent,flags);
            usbManager.requestPermission(dev,pi);
            setStatus("Czekam na zgodę Androida na dostęp do USB…");
        } else openPort(e);
    }

    private void openPort(PortEntry e) {
        try {
            int baud=Integer.parseInt(baudSpinner.getSelectedItem().toString());
            usbConnection=usbManager.openDevice(e.driver.getDevice());
            if(usbConnection==null) throw new IOException("Android nie otworzył urządzenia USB.");
            serialPort=e.driver.getPorts().get(e.portIndex);
            serialPort.open(usbConnection);
            serialPort.setParameters(baud,8,UsbSerialPort.STOPBITS_1,UsbSerialPort.PARITY_NONE);
            try { serialPort.setDTR(true); } catch(Exception ignored){}
            try { serialPort.setRTS(true); } catch(Exception ignored){}
            ioManager=new SerialInputOutputManager(serialPort,this);
            ioManager.start();
            connected=true;
            connectButton.setText("Rozłącz"); startButton.setEnabled(true); stopButton.setEnabled(false);
            refreshButton.setEnabled(false); deviceSpinner.setEnabled(false); baudSpinner.setEnabled(false);
            setStatus("POŁĄCZONO: "+e.label+" @ "+baud+" baud – naciśnij START");
        } catch(Exception ex){ closeSerial(); setStatus("Błąd połączenia USB: "+ex.getMessage()); alert("Błąd połączenia",ex.toString()); }
    }

    private void disconnect(boolean userRequested) {
        if(sessionActive) stopMeasurement(userRequested);
        closeSerial();
        connected=false;
        runOnUiThread(()->{
            connectButton.setText("Połącz"); startButton.setEnabled(false); stopButton.setEnabled(false);
            refreshButton.setEnabled(true); deviceSpinner.setEnabled(true); baudSpinner.setEnabled(true);
            setStatus("Niepołączony");
        });
    }

    private void closeSerial() {
        try { if(ioManager!=null) ioManager.stop(); } catch(Exception ignored){}
        ioManager=null;
        try { if(serialPort!=null) serialPort.close(); } catch(Exception ignored){}
        serialPort=null;
        try { if(usbConnection!=null) usbConnection.close(); } catch(Exception ignored){}
        usbConnection=null;
        synchronized(serialTextBuffer){ serialTextBuffer.setLength(0); }
    }

    private Settings readSettings(boolean showError) {
        try{
            double threshold=parseEdit(thresholdEdit), scale=parseEdit(scaleEdit), pre=parseEdit(pretriggerEdit);
            double fmin=parseEdit(fminEdit), fmax=parseEdit(fmaxEdit), window=parseEdit(windowEdit);
            if(threshold<=0||scale==0||pre<0||fmin<=0||fmax<=fmin||window<2.0) throw new IllegalArgumentException();
            return new Settings(threshold,scale,pre,fmin,fmax,window);
        }catch(Exception e){ if(showError) alert("Błędne ustawienia","Wymagane: próg > 0, skala ≠ 0, pretrigger ≥ 0, 0 < f min < f max, okno analizy ≥ 2 s."); return null; }
    }

    private double parseEdit(EditText e){ return Double.parseDouble(e.getText().toString().trim().replace(',','.')); }

    private void startMeasurement() {
        if(!connected){ toast("Najpierw połącz urządzenie."); return; }
        Settings startSettings = readSettings(true);
        if(startSettings==null) return;
        activeSettings = startSettings;
        kalmanEnabled = kalmanCheck.isChecked();
        autoGEnabled = autoGCheck.isChecked();
        setConfigEnabled(false);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        synchronized(stateLock){
            if(recorder!=null){ recorder.abort(); recorder=null; }
            sessionActive=true; calibrating=true; calibrationStartSec=-1; calibrationSamples.clear();
            autoScaleFactor=1.0; reference=null; motionHits=0; triggered=false; plotStartSec=-1;
            sampleCount=0; badLineCount=0; lastUiSec=0; lastOscScheduleSec=0;
            kx=new Kalman1D(KALMAN_Q,KALMAN_R); ky=new Kalman1D(KALMAN_Q,KALMAN_R); kz=new Kalman1D(KALMAN_Q,KALMAN_R);
            oscBuffer.clear(); preBuffer.clear(); currentOsc=null; chart.clear();
        }
        resetOscUi();
        startButton.setEnabled(false); stopButton.setEnabled(true);
        fileText.setText("Plik: oczekiwanie na kalibrację i ruch");
        statsText.setText("Próbki: 0 | błędne linie: 0");
        setStatus("START – KALIBRACJA 2.0 s: NIE RUSZAJ CZUJNIKIEM");
    }

    private void stopMeasurement(boolean showResult) {
        SessionRecorder toExport=null;
        synchronized(stateLock){
            if(!sessionActive && recorder==null) return;
            sessionActive=false; calibrating=false; calibrationSamples.clear(); reference=null; motionHits=0; preBuffer.clear(); oscBuffer.clear();
            if(recorder!=null){ toExport=recorder; recorder=null; }
        }
        startButton.setEnabled(connected); stopButton.setEnabled(false);
        setConfigEnabled(true);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setStatus("STOP – pomiar zatrzymany; USB pozostaje połączone");
        if(toExport!=null){
            fileText.setText("Plik: tworzę CSV + Excel…");
            SessionRecorder finalRecorder=toExport;
            exportExecutor.submit(()->{
                try{
                    SessionRecorder.ExportResult result=finalRecorder.finishAndExport();
                    runOnUiThread(()->{
                        if(result!=null){
                            fileText.setText("Excel: "+result.xlsxLocation);
                            if(showResult) new AlertDialog.Builder(this).setTitle("Zapis zakończony")
                                    .setMessage("CSV:\n"+result.csvLocation+"\n\nExcel:\n"+result.xlsxLocation)
                                    .setPositiveButton("OK",null).show();
                        }
                    });
                }catch(Exception e){ runOnUiThread(()->{ fileText.setText("Błąd zapisu: "+e.getMessage()); alert("Błąd zapisu",e.toString()); }); }
            });
        } else fileText.setText("Plik: brak zapisu – nie wykryto ruchu");
    }

    @Override public void onNewData(byte[] data) {
        String chunk=new String(data,StandardCharsets.UTF_8);
        ArrayList<String> lines=new ArrayList<>();
        synchronized(serialTextBuffer){
            serialTextBuffer.append(chunk);
            int nl;
            while((nl=indexOfNewline(serialTextBuffer))>=0){
                String line=serialTextBuffer.substring(0,nl).trim();
                serialTextBuffer.delete(0,nl+1);
                if(!line.isEmpty()) lines.add(line);
            }
            if(serialTextBuffer.length()>8192) serialTextBuffer.delete(0,serialTextBuffer.length()-4096);
        }
        for(String line:lines) processLine(line,System.nanoTime()/1e9);
    }

    private static int indexOfNewline(StringBuilder b){ for(int i=0;i<b.length();i++) if(b.charAt(i)=='\n') return i; return -1; }

    @Override public void onRunError(Exception e) {
        runOnUiThread(()->{ setStatus("Błąd USB: "+e.getMessage()); disconnect(false); });
    }

    private void processLine(String line,double perfSec) {
        double[] xyz=parseXyz(line);
        synchronized(stateLock){
            if(!sessionActive) return;
            if(xyz==null){ badLineCount++; return; }
            Settings st=activeSettings; if(st==null) return;
            double rx=xyz[0]*st.scale, ry=xyz[1]*st.scale, rz=xyz[2]*st.scale;

            if(calibrating){
                if(calibrationStartSec<0) calibrationStartSec=perfSec;
                calibrationSamples.add(new double[]{rx,ry,rz});
                double elapsed=perfSec-calibrationStartSec;
                if(elapsed>=CALIBRATION_SECONDS && calibrationSamples.size()>=MIN_CALIBRATION_SAMPLES) finishCalibration();
                else if(perfSec-lastUiSec>=UI_UPDATE_SECONDS){ lastUiSec=perfSec; double shown=Math.min(CALIBRATION_SECONDS,elapsed); runOnUiThread(()->setStatus(String.format(Locale.US,"START – KALIBRACJA %.1f/2.0 s: NIE RUSZAJ CZUJNIKIEM",shown))); }
                return;
            }

            double xm=rx*autoScaleFactor, ym=ry*autoScaleFactor, zm=rz*autoScaleFactor;
            oscBuffer.addLast(new OscillationAnalyzer.Sample(perfSec,xm,ym,zm));
            while(!oscBuffer.isEmpty() && perfSec-oscBuffer.peekFirst().t>st.window) oscBuffer.removeFirst();
            if(perfSec-lastOscScheduleSec>=OSC_UPDATE_SECONDS && !analysisRunning.getAndSet(true)){
                lastOscScheduleSec=perfSec;
                ArrayList<OscillationAnalyzer.Sample> snapshot=new ArrayList<>(oscBuffer);
                analysisExecutor.submit(()->{
                    try{ OscillationAnalyzer.Result r=OscillationAnalyzer.analyze(snapshot,st.fmin,st.fmax); if(r!=null) currentOsc=r; }
                    finally{ analysisRunning.set(false); }
                });
            }

            double x=kalmanEnabled?kx.update(xm):xm;
            double y=kalmanEnabled?ky.update(ym):ym;
            double z=kalmanEnabled?kz.update(zm):zm;
            if(plotStartSec<0) plotStartSec=perfSec;
            double t=perfSec-plotStartSec;
            double mag=Math.sqrt(x*x+y*y+z*z);
            if(reference==null) reference=new double[]{x,y,z};
            double dx=x-reference[0],dy=y-reference[1],dz=z-reference[2];
            double delta=Math.sqrt(dx*dx+dy*dy+dz*dz);

            if(!triggered){
                if(delta>=st.threshold) motionHits++; else {
                    motionHits=0;
                    if(delta<st.threshold*0.5){ double a=0.003; reference[0]=(1-a)*reference[0]+a*x; reference[1]=(1-a)*reference[1]+a*y; reference[2]=(1-a)*reference[2]+a*z; }
                }
                SessionRecorder.DataRow row=makeRow(x,y,z,mag,delta,currentOsc);
                preBuffer.addLast(new TimedRow(perfSec,row));
                while(!preBuffer.isEmpty()&&perfSec-preBuffer.peekFirst().perfSec>st.pretrigger) preBuffer.removeFirst();
                if(motionHits>=5){
                    try{
                        String base="ADXL345_"+LocalDateTime.now().format(fileStamp);
                        recorder=new SessionRecorder(this); recorder.start(base); triggered=true; recordStartSec=perfSec;
                        for(TimedRow tr:preBuffer){ tr.row.timeFromTrigger=tr.perfSec-recordStartSec; recorder.write(tr.row); }
                        preBuffer.clear();
                        runOnUiThread(()->{ fileText.setText("Zapis: "+base+".xlsx"); setStatus(String.format(Locale.US,"RUCH WYKRYTY – ZAPIS | Δa=%.3f g | próg=%.3f g",delta,st.threshold)); });
                    }catch(Exception e){ SessionRecorder bad=recorder; recorder=null; if(bad!=null)bad.abort(); sessionActive=false; runOnUiThread(()->alert("Błąd zapisu",e.toString())); return; }
                }
            } else if(recorder!=null){
                SessionRecorder.DataRow row=makeRow(x,y,z,mag,delta,currentOsc); row.timeFromTrigger=perfSec-recordStartSec;
                try{ recorder.write(row); }catch(IOException e){ SessionRecorder bad=recorder; recorder=null; if(bad!=null)bad.abort(); sessionActive=false; runOnUiThread(()->alert("Błąd zapisu",e.toString())); return; }
            }

            sampleCount++;
            OscillationAnalyzer.Result osc=currentOsc;
            if(perfSec-lastUiSec>=UI_UPDATE_SECONDS){
                lastUiSec=perfSec;
                long sc=sampleCount, bc=badLineCount;
                runOnUiThread(()->updateUi(t,x,y,z,mag,delta,osc,sc,bc));
            }
        }
    }

    private SessionRecorder.DataRow makeRow(double x,double y,double z,double mag,double delta,OscillationAnalyzer.Result o){
        SessionRecorder.DataRow r=new SessionRecorder.DataRow(); r.timeIso=LocalDateTime.now().format(isoStamp); r.x=x;r.y=y;r.z=z;r.mag=mag;r.delta=delta;r.osc=o; return r;
    }

    private void finishCalibration(){
        double bx=medianAxis(0),by=medianAxis(1),bz=medianAxis(2);
        double rest=Math.sqrt(bx*bx+by*by+bz*bz);
        autoScaleFactor=(autoGEnabled&&rest>1e-9)?1.0/rest:1.0;
        bx*=autoScaleFactor; by*=autoScaleFactor; bz*=autoScaleFactor;
        reference=new double[]{bx,by,bz}; kx.reset(bx);ky.reset(by);kz.reset(bz);
        calibrating=false; calibrationSamples.clear(); motionHits=0; preBuffer.clear(); oscBuffer.clear(); plotStartSec=-1;
        double factor=autoScaleFactor;
        runOnUiThread(()->setStatus(String.format(Locale.US,"KALIBRACJA OK – auto 1g x%.5f; CZEKAM NA RUCH",factor)));
    }

    private double medianAxis(int axis){
        ArrayList<Double> v=new ArrayList<>(); for(double[] p:calibrationSamples)v.add(p[axis]); Collections.sort(v); int n=v.size(); return n%2==1?v.get(n/2):0.5*(v.get(n/2-1)+v.get(n/2));
    }

    private void updateUi(double t,double x,double y,double z,double mag,double delta,OscillationAnalyzer.Result o,long sc,long bc){
        currentValues.setText(String.format(Locale.US,"X: %+.4f g   Y: %+.4f g   Z: %+.4f g   |a|: %.4f g   Δa: %.4f g",x,y,z,mag,delta));
        chart.add(t,x,y,z,mag);
        if(o!=null){
            frequencyText.setText(String.format(Locale.US,"Częstotliwość: %.3f Hz",o.frequencyHz));
            accelText.setText(String.format(Locale.US,"A przysp.: %.4f g    Amplituda: %.3f mm",o.accelPeakG,o.amplitudeMm));
            strokeText.setText(String.format(Locale.US,"SKOK P-P: %.3f mm",o.strokePpMm));
            qualityText.setText(String.format(Locale.US,"Jakość: %.0f %%   Próbkowanie: %.1f Hz",o.qualityPct,o.sampleRateHz));
        }
        statsText.setText("Próbki: "+sc+" | błędne linie: "+bc);
    }


    private void setConfigEnabled(boolean enabled){
        thresholdEdit.setEnabled(enabled); scaleEdit.setEnabled(enabled); pretriggerEdit.setEnabled(enabled);
        fminEdit.setEnabled(enabled); fmaxEdit.setEnabled(enabled); windowEdit.setEnabled(enabled);
        kalmanCheck.setEnabled(enabled); autoGCheck.setEnabled(enabled);
    }

    private void resetOscUi(){
        currentValues.setText("X: --   Y: --   Z: --   |a|: --   Δa: --"); frequencyText.setText("Częstotliwość: -- Hz");
        accelText.setText("A przysp.: -- g    Amplituda: -- mm"); strokeText.setText("SKOK P-P: -- mm"); qualityText.setText("Jakość: -- %   Próbkowanie: -- Hz");
    }

    static double[] parseXyz(String line){
        if(line==null) return null; String s=line.trim(); if(s.isEmpty())return null;
        Matcher m=XYZ_PATTERN.matcher(s); if(m.find())try{return new double[]{toDouble(m.group(1)),toDouble(m.group(2)),toDouble(m.group(3))};}catch(Exception ignored){}
        if(s.contains(";")){ String[] p=s.split(";"); if(p.length>=3)try{return new double[]{toDouble(p[0]),toDouble(p[1]),toDouble(p[2])};}catch(Exception ignored){} }
        String[] comma=s.split(","); if(comma.length>=3)try{return new double[]{Double.parseDouble(comma[0].trim()),Double.parseDouble(comma[1].trim()),Double.parseDouble(comma[2].trim())};}catch(Exception ignored){}
        String[] ws=s.split("\\s+"); if(ws.length>=3)try{return new double[]{toDouble(ws[0]),toDouble(ws[1]),toDouble(ws[2])};}catch(Exception ignored){}
        return null;
    }
    private static double toDouble(String s){ return Double.parseDouble(s.trim().replace(',','.')); }

    private void setStatus(String s){ if(statusText!=null) statusText.setText(s); }
    private void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
    private void alert(String title,String msg){ new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK",null).show(); }

    @Override protected void onDestroy(){
        try{ unregisterReceiver(permissionReceiver); }catch(Exception ignored){}
        synchronized(stateLock){ sessionActive=false; if(recorder!=null){recorder.abort();recorder=null;} }
        closeSerial(); analysisExecutor.shutdownNow(); exportExecutor.shutdown(); super.onDestroy();
    }
}

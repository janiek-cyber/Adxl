ADXL345 Android - projekt do budowania online

Ten ZIP jest przeznaczony do użycia z plikiem .github/workflows/build-apk.yml.
Nie rozpakowuj go w repozytorium GitHub. Wgraj go jako:
ADXL345_ANDROID_PROJEKT.zip

Workflow sam go rozpakowuje i tworzy APK.

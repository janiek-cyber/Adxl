package pl.zut.adxl345;

final class Kalman1D {
    private final double q;
    private final double r;
    private double x;
    private double p = 1.0;
    private boolean initialized = false;

    Kalman1D(double q, double r) {
        this.q = q;
        this.r = r;
    }

    void reset(double value) {
        x = value;
        p = 1.0;
        initialized = true;
    }

    double update(double measurement) {
        if (!initialized) {
            reset(measurement);
            return measurement;
        }
        p += q;
        double k = p / (p + r);
        x += k * (measurement - x);
        p *= (1.0 - k);
        return x;
    }
}

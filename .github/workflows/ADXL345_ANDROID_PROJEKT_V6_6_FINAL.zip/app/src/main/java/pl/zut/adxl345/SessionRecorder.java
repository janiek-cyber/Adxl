package pl.zut.adxl345;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

final class SessionRecorder {
    static final class DataRow {
        String timeIso; double timeFromStart; double x,y,z,mag,delta;
        Long deviceUs; OscillationAnalyzer.Result osc; OscillationAnalyzer.DirectionResult direction;
    }

    static final class Stats {
        long rows=0,validStrokeCount=0,directionCount=0;
        double strokeSum=0,freqSum=0,qualitySum=0,dominanceSum=0;
        double angleXYCos2=0,angleXYSin2=0;
        double angleXZCos2=0,angleXZSin2=0;
        double angleYZCos2=0,angleYZSin2=0;
        Double strokeMin=null,strokeMax=null,lastStroke=null;

        void add(DataRow r){
            rows++;
            if(r.osc!=null&&r.osc.reliable()&&Double.isFinite(r.osc.strokePpMm)){
                double s=r.osc.strokePpMm;
                validStrokeCount++;
                strokeSum+=s;
                freqSum+=r.osc.frequencyHz;
                qualitySum+=r.osc.qualityPct;
                strokeMin=strokeMin==null?s:Math.min(strokeMin,s);
                strokeMax=strokeMax==null?s:Math.max(strokeMax,s);
                lastStroke=s;
            }
            if(r.direction!=null&&r.direction.reliable()){
                directionCount++;
                dominanceSum+=r.direction.dominancePct;
                addAxialAngle(r.direction.angleXYDeg,0);
                addAxialAngle(r.direction.angleXZDeg,1);
                addAxialAngle(r.direction.angleYZDeg,2);
            }
        }

        private void addAxialAngle(double deg,int plane){
            if(!Double.isFinite(deg)) return;
            double a=Math.toRadians(2.0*deg);
            double c=Math.cos(a),s=Math.sin(a);
            if(plane==0){angleXYCos2+=c;angleXYSin2+=s;}
            else if(plane==1){angleXZCos2+=c;angleXZSin2+=s;}
            else {angleYZCos2+=c;angleYZSin2+=s;}
        }

        private Double axialMean(double c,double s){
            if(directionCount==0) return null;
            double deg=0.5*Math.toDegrees(Math.atan2(s,c));
            while(deg>90.0) deg-=180.0;
            while(deg<=-90.0) deg+=180.0;
            return deg;
        }

        Double meanStroke(){return validStrokeCount==0?null:strokeSum/validStrokeCount;}
        Double meanFreq(){return validStrokeCount==0?null:freqSum/validStrokeCount;}
        Double meanQuality(){return validStrokeCount==0?null:qualitySum/validStrokeCount;}
        Double meanAngleXY(){return axialMean(angleXYCos2,angleXYSin2);}
        Double meanAngleXZ(){return axialMean(angleXZCos2,angleXZSin2);}
        Double meanAngleYZ(){return axialMean(angleYZCos2,angleYZSin2);}
        Double meanDominance(){return directionCount==0?null:dominanceSum/directionCount;}
    }

    static final class ExportResult { final String csvLocation,xlsxLocation; ExportResult(String c,String x){csvLocation=c;xlsxLocation=x;} }
    private final Context context;private final Stats stats=new Stats();private File tempCsv;private BufferedWriter writer;private String baseName;
    SessionRecorder(Context c){context=c.getApplicationContext();} Stats getStats(){return stats;}

    void start(String base) throws IOException{
        baseName=base;tempCsv=new File(context.getCacheDir(),base+".csv");writer=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tempCsv),StandardCharsets.UTF_8));writer.write('\uFEFF');
        writer.write("czas_iso;czas_od_startu_s;X_g;Y_g;Z_g;modul_g;delta_od_spoczynku_g;czas_RP2040_us;czestotliwosc_Hz;amplituda_przyspieszenia_g;amplituda_przemieszczenia_mm;skok_PP_mm;jakosc_oscylacji_pct;czestotliwosc_probkowania_Hz;dir_x;dir_y;dir_z;kat_XY_deg;kat_XZ_deg;kat_YZ_deg;kat_od_poziomu_deg;kat_od_pionu_deg;odchylenie_boczne_deg;kat_do_osi_wzdluznej_deg;dominacja_PCA_pct;rms_dynamic_g;os_wzdluzna\n");
    }

    void write(DataRow r)throws IOException{
        if(writer==null)return;OscillationAnalyzer.Result o=r.osc;OscillationAnalyzer.DirectionResult d=r.direction;boolean ok=o!=null&&o.reliable();
        writer.write(s(r.timeIso));writer.write(';');writer.write(f(r.timeFromStart));writer.write(';');writer.write(f(r.x));writer.write(';');writer.write(f(r.y));writer.write(';');writer.write(f(r.z));writer.write(';');writer.write(f(r.mag));writer.write(';');writer.write(f(r.delta));writer.write(';');writer.write(r.deviceUs==null?"":Long.toString(r.deviceUs));writer.write(';');
        writer.write(ok?f(o.frequencyHz):"");writer.write(';');writer.write(ok?f(o.accelPeakG):"");writer.write(';');writer.write(ok?f(o.amplitudeMm):"");writer.write(';');writer.write(ok?f(o.strokePpMm):"");writer.write(';');writer.write(o==null?"":f(o.qualityPct));writer.write(';');writer.write(o==null?"":f(o.sampleRateHz));writer.write(';');
        writer.write(d==null?"":f(d.dirX));writer.write(';');writer.write(d==null?"":f(d.dirY));writer.write(';');writer.write(d==null?"":f(d.dirZ));writer.write(';');writer.write(d==null?"":f(d.angleXYDeg));writer.write(';');writer.write(d==null?"":f(d.angleXZDeg));writer.write(';');writer.write(d==null?"":f(d.angleYZDeg));writer.write(';');writer.write(d==null?"":f(d.angleFromHorizontalDeg));writer.write(';');writer.write(d==null?"":f(d.angleFromVerticalDeg));writer.write(';');writer.write(d==null?"":f(d.lateralDeviationDeg));writer.write(';');writer.write(d==null?"":f(d.angleToLongitudinalDeg));writer.write(';');writer.write(d==null?"":f(d.dominancePct));writer.write(';');writer.write(d==null?"":f(d.rmsDynamicG));writer.write(';');writer.write(d==null?"":s(d.longitudinalAxis));writer.write('\n');
        stats.add(r);if(stats.rows%100==0)writer.flush();
    }

    ExportResult finishAndExport()throws IOException{
        if(writer==null||tempCsv==null)return null;writer.flush();writer.close();writer=null;String csvName=baseName+".csv",xlsxName=baseName+".xlsx",csvLocation,xlsxLocation;
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q){csvLocation=exportMediaStore(csvName,"text/csv",out->copy(tempCsv,out));xlsxLocation=exportMediaStore(xlsxName,"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",out->XlsxExporter.write(out,tempCsv,stats));}
        else{File root=new File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"ADXL345");if(!root.exists()&&!root.mkdirs())throw new IOException("Nie można utworzyć folderu: "+root);File csv=new File(root,csvName),xlsx=new File(root,xlsxName);try(OutputStream o=new FileOutputStream(csv)){copy(tempCsv,o);}try(OutputStream o=new FileOutputStream(xlsx)){XlsxExporter.write(o,tempCsv,stats);}csvLocation=csv.getAbsolutePath();xlsxLocation=xlsx.getAbsolutePath();}
        tempCsv.delete();tempCsv=null;return new ExportResult(csvLocation,xlsxLocation);
    }
    void abort(){try{if(writer!=null)writer.close();}catch(Exception ignored){}writer=null;if(tempCsv!=null)tempCsv.delete();tempCsv=null;}
    private interface StreamWriter{void write(OutputStream out)throws IOException;}
    private String exportMediaStore(String name,String mime,StreamWriter sw)throws IOException{ContentResolver r=context.getContentResolver();ContentValues v=new ContentValues();v.put(MediaStore.MediaColumns.DISPLAY_NAME,name);v.put(MediaStore.MediaColumns.MIME_TYPE,mime);v.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOCUMENTS+"/ADXL345");v.put(MediaStore.MediaColumns.IS_PENDING,1);Uri uri=r.insert(MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),v);if(uri==null)throw new IOException("Nie można utworzyć "+name);try{try(OutputStream out=r.openOutputStream(uri,"w")){if(out==null)throw new IOException("Nie można otworzyć "+name);sw.write(out);}ContentValues ready=new ContentValues();ready.put(MediaStore.MediaColumns.IS_PENDING,0);r.update(uri,ready,null,null);}catch(IOException e){r.delete(uri,null,null);throw e;}return Environment.DIRECTORY_DOCUMENTS+"/ADXL345/"+name;}
    private static void copy(File src,OutputStream out)throws IOException{try(FileInputStream in=new FileInputStream(src)){byte[]b=new byte[65536];int n;while((n=in.read(b))>=0)out.write(b,0,n);}}
    private static String s(String v){return v==null?"":v.replace(";",",").replace("\n"," ").replace("\r"," ");}
    private static String f(double v){return Double.isFinite(v)?String.format(Locale.US,"%.6f",v):"";}
}

package pl.zut.adxl345;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;

public class SplashActivity extends Activity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);setContentView(R.layout.activity_splash);
        ImageView logo=findViewById(R.id.splashLogo);
        ObjectAnimator alpha=ObjectAnimator.ofFloat(logo,"alpha",0.55f,1.0f,0.65f,1.0f);
        alpha.setDuration(1250);alpha.setInterpolator(new AccelerateDecelerateInterpolator());
        ObjectAnimator sx=ObjectAnimator.ofFloat(logo,"scaleX",0.96f,1.035f,1.0f);
        ObjectAnimator sy=ObjectAnimator.ofFloat(logo,"scaleY",0.96f,1.035f,1.0f);
        sx.setDuration(1250);sy.setDuration(1250);
        AnimatorSet set=new AnimatorSet();set.playTogether(alpha,sx,sy);set.start();
        new Handler(Looper.getMainLooper()).postDelayed(()->{startActivity(new Intent(this,MainActivity.class));finish();},1450);
    }
}

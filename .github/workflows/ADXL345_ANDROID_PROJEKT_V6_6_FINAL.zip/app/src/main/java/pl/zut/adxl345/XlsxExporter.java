package pl.zut.adxl345;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Lekki generator XLSX bez Apache POI.
 *
 * V6.6:
 * - Podsumowanie
 * - Dane_1
 * - Kierunki: 3 wykresy XY/XZ/YZ z wektorem PCA, osią 0° i łukiem theta.
 */
final class XlsxExporter {
    private static final int EXCEL_MAX_ROWS = 1_048_576;
    private static final int ARC_POINTS = 21;

    static void write(OutputStream target, File csvFile, SessionRecorder.Stats stats) throws IOException {
        try (ZipOutputStream zip = new ZipOutputStream(target, StandardCharsets.UTF_8)) {
            text(zip, "[Content_Types].xml", contentTypes());
            text(zip, "_rels/.rels", rootRels());
            text(zip, "docProps/app.xml", appProps());
            text(zip, "docProps/core.xml", coreProps());

            text(zip, "xl/workbook.xml", workbook());
            text(zip, "xl/_rels/workbook.xml.rels", workbookRels());
            text(zip, "xl/styles.xml", styles());

            summarySheet(zip, stats);
            dataSheet(zip, csvFile);
            directionSheet(zip, stats);

            text(zip, "xl/worksheets/_rels/sheet3.xml.rels", directionSheetRels());
            text(zip, "xl/drawings/drawing1.xml", drawing());
            text(zip, "xl/drawings/_rels/drawing1.xml.rels", drawingRels());

            text(zip, "xl/charts/chart1.xml",
                    scatterChart("XY", "A", "B", "C", "D", "E", "F", stats.meanAngleXY(), stats));
            text(zip, "xl/charts/chart2.xml",
                    scatterChart("XZ", "H", "I", "J", "K", "L", "M", stats.meanAngleXZ(), stats));
            text(zip, "xl/charts/chart3.xml",
                    scatterChart("YZ", "O", "P", "Q", "R", "S", "T", stats.meanAngleYZ(), stats));
        }
    }

    private static void summarySheet(ZipOutputStream zip, SessionRecorder.Stats s) throws IOException {
        zip.putNextEntry(new ZipEntry("xl/worksheets/sheet1.xml"));
        OutputStreamWriter w = new OutputStreamWriter(zip, StandardCharsets.UTF_8);

        w.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        w.write("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");

        row(w, 1, new Cell[]{str("Parametr", true), str("Wartość", true), str("Uwagi", true)});

        int r = 2;
        r = summaryRow(w, r, "Liczba zapisanych próbek", (double)s.rows, "wiersze danych");
        r = summaryRow(w, r, "Liczba wiarygodnych wyników skoku", (double)s.validStrokeCount, "jakość FFT >= 60%");
        r = summaryRow(w, r, "Średni SKOK P-P", s.meanStroke(), "mm; jakość FFT >= 60%");
        r = summaryRow(w, r, "Minimalny SKOK P-P", s.strokeMin, "mm; jakość FFT >= 60%");
        r = summaryRow(w, r, "Maksymalny SKOK P-P", s.strokeMax, "mm; jakość FFT >= 60%");
        r = summaryRow(w, r, "Ostatni SKOK P-P", s.lastStroke, "mm; jakość FFT >= 60%");
        r = summaryRow(w, r, "Średnia częstotliwość", s.meanFreq(), "Hz; jakość FFT >= 60%");
        r = summaryRow(w, r, "Średnia jakość", s.meanQuality(), "%");

        r = summaryRow(w, r, "Liczba wiarygodnych kierunków PCA", (double)s.directionCount, "dominacja PCA >= 55%");
        r = summaryRow(w, r, "Średni kąt θXY", s.meanAngleXY(), "deg; średnia osiowa");
        r = summaryRow(w, r, "Średni kąt θXZ", s.meanAngleXZ(), "deg; średnia osiowa");
        r = summaryRow(w, r, "Średni kąt θYZ", s.meanAngleYZ(), "deg; średnia osiowa");
        r = summaryRow(w, r, "Średnia dominacja PCA", s.meanDominance(), "%");

        r = summaryText(w, r, "Wykresy kierunku", "Arkusz: Kierunki", "XY / XZ / YZ + oś 0° + łuk theta");
        r = summaryText(w, r, "Metoda", "PCA + dopasowanie sinusoidy", "SKOK P-P = 2*a_peak*g/(2*pi*f)^2");
        summaryText(w, r, "Uwaga", "Kąt PCA może istnieć bez wiarygodnego FFT", "Skok w mm wymaga jakości FFT >= 60%.");

        w.write("</sheetData></worksheet>");
        w.flush();
        zip.closeEntry();
    }

    private static int summaryRow(OutputStreamWriter w, int r, String name, Double value, String note) throws IOException {
        row(w, r, new Cell[]{
                str(name, false),
                value == null ? str("", false) : num(value),
                str(note, false)
        });
        return r + 1;
    }

    private static int summaryText(OutputStreamWriter w, int r, String name, String value, String note) throws IOException {
        row(w, r, new Cell[]{str(name, false), str(value, false), str(note, false)});
        return r + 1;
    }

    private static void dataSheet(ZipOutputStream zip, File csvFile) throws IOException {
        zip.putNextEntry(new ZipEntry("xl/worksheets/sheet2.xml"));
        OutputStreamWriter w = new OutputStreamWriter(zip, StandardCharsets.UTF_8);

        w.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        w.write("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
        w.write("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>");
        w.write("<sheetData>");

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(csvFile), StandardCharsets.UTF_8))) {
            String line;
            int r = 1;
            while ((line = br.readLine()) != null && r <= EXCEL_MAX_ROWS) {
                if (r == 1 && line.startsWith("\uFEFF")) line = line.substring(1);
                String[] p = line.split(";", -1);
                Cell[] cells = new Cell[p.length];

                for (int c = 0; c < p.length; c++) {
                    if (r == 1 || c == 0 || p[c].isEmpty()) {
                        cells[c] = str(p[c], r == 1);
                    } else {
                        try { cells[c] = num(Double.parseDouble(p[c])); }
                        catch (NumberFormatException e) { cells[c] = str(p[c], false); }
                    }
                }
                row(w, r, cells);
                r++;
            }
        }

        w.write("</sheetData></worksheet>");
        w.flush();
        zip.closeEntry();
    }

    private static void directionSheet(ZipOutputStream zip, SessionRecorder.Stats s) throws IOException {
        zip.putNextEntry(new ZipEntry("xl/worksheets/sheet3.xml"));
        OutputStreamWriter w = new OutputStreamWriter(zip, StandardCharsets.UTF_8);

        w.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        w.write("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" ");
        w.write("xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">");

        w.write("<cols>");
        w.write("<col min=\"1\" max=\"20\" width=\"12\" customWidth=\"1\"/>");
        w.write("</cols>");

        w.write("<sheetData>");

        row(w, 1, padded(20,
                str("ADXL345 PRO Android V6.6 – KIERUNKI PCA", true)));
        row(w, 2, padded(20,
                str("Wiarygodne okna PCA", false), num(s.directionCount),
                str("Dominacja średnia [%]", false), nullableNum(s.meanDominance())));
        row(w, 3, padded(20,
                str("θXY [deg]", false), nullableNum(s.meanAngleXY()),
                str("θXZ [deg]", false), nullableNum(s.meanAngleXZ()),
                str("θYZ [deg]", false), nullableNum(s.meanAngleYZ())));
        row(w, 4, padded(20,
                str("Interpretacja", false),
                str("Wektor drgań jest osią: +u i -u oznaczają ten sam kierunek.", false)));

        // Dane pomocnicze dla wszystkich 3 wykresów zapisujemy w jednym
        // przebiegu po wierszach. W XLSX nie mogą istnieć wielokrotnie
        // te same numery wierszy <row r=\"...\">.
        final int headerRow = 70;

        Cell[] hdr = blankCells(20);
        setPlaneHeaders(hdr, 0, "XY");
        setPlaneHeaders(hdr, 7, "XZ");
        setPlaneHeaders(hdr, 14, "YZ");
        row(w, headerRow, hdr);

        for (int i = 0; i < ARC_POINTS; i++) {
            Cell[] cells = blankCells(20);
            fillPlaneData(cells, 0, s.meanAngleXY(), i);
            fillPlaneData(cells, 7, s.meanAngleXZ(), i);
            fillPlaneData(cells, 14, s.meanAngleYZ(), i);
            row(w, headerRow + 1 + i, cells);
        }

        w.write("</sheetData>");
        w.write("<drawing r:id=\"rId1\"/>");
        w.write("</worksheet>");

        w.flush();
        zip.closeEntry();
    }

    private static void setPlaneHeaders(Cell[] row, int startCol0, String plane) {
        row[startCol0] = str(plane + "_vec_X", true);
        row[startCol0 + 1] = str(plane + "_vec_Y", true);
        row[startCol0 + 2] = str(plane + "_ref_X", true);
        row[startCol0 + 3] = str(plane + "_ref_Y", true);
        row[startCol0 + 4] = str(plane + "_arc_X", true);
        row[startCol0 + 5] = str(plane + "_arc_Y", true);
    }

    private static void fillPlaneData(Cell[] cells, int startCol0, Double angleDeg, int i) {
        boolean ok = angleDeg != null && Double.isFinite(angleDeg);
        if (!ok) return;

        double a = Math.toRadians(angleDeg);
        double ux = Math.cos(a);
        double uy = Math.sin(a);
        double radius = 0.45;

        // Wektor PCA: -u -> 0 -> +u.
        if (i == 0) {
            cells[startCol0] = num(-ux);
            cells[startCol0 + 1] = num(-uy);
        } else if (i == 1) {
            cells[startCol0] = num(0);
            cells[startCol0 + 1] = num(0);
        } else if (i == 2) {
            cells[startCol0] = num(ux);
            cells[startCol0 + 1] = num(uy);
        }

        // Oś odniesienia 0°.
        if (i == 0) {
            cells[startCol0 + 2] = num(0);
            cells[startCol0 + 3] = num(0);
        } else if (i == 1) {
            cells[startCol0 + 2] = num(1);
            cells[startCol0 + 3] = num(0);
        }

        // Łuk kąta od 0° do theta.
        double fi = a * i / (ARC_POINTS - 1.0);
        cells[startCol0 + 4] = num(radius * Math.cos(fi));
        cells[startCol0 + 5] = num(radius * Math.sin(fi));
    }

    private static Cell[] padded(int n, Cell... prefix) {
        Cell[] out = blankCells(n);
        for (int i = 0; i < prefix.length && i < n; i++) out[i] = prefix[i];
        return out;
    }

    private static Cell[] blankCells(int n) {
        Cell[] out = new Cell[n];
        for (int i = 0; i < n; i++) out[i] = str("", false);
        return out;
    }

    private static Cell nullableNum(Double d) {
        return d == null || !Double.isFinite(d) ? str("", false) : num(d);
    }

    private static String scatterChart(
            String plane,
            String vx, String vy,
            String rx, String ry,
            String ax, String ay,
            Double angleDeg,
            SessionRecorder.Stats stats) {

        String title;
        if (angleDeg == null || !Double.isFinite(angleDeg) || stats.directionCount == 0) {
            title = plane + " – brak wiarygodnego kierunku PCA";
        } else {
            String dom = stats.meanDominance() == null ? "--" :
                    String.format(Locale.US, "%.0f", stats.meanDominance());
            title = String.format(Locale.US, "%s – θ = %+.1f° | PCA %s%%",
                    plane, angleDeg, dom);
        }

        long xAxis = plane.equals("XY") ? 51000001L : plane.equals("XZ") ? 52000001L : 53000001L;
        long yAxis = xAxis + 1;

        int dirStart = 71, dirEnd = 73;
        int refStart = 71, refEnd = 72;
        int arcStart = 71, arcEnd = 70 + ARC_POINTS;

        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<c:chartSpace xmlns:c=\"http://schemas.openxmlformats.org/drawingml/2006/chart\" " +
                "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                "<c:chart>" +
                chartTitle(title) +
                "<c:autoTitleDeleted val=\"0\"/>" +
                "<c:plotArea><c:layout/>" +
                "<c:scatterChart><c:scatterStyle val=\"lineMarker\"/><c:varyColors val=\"0\"/>" +

                scatterSeries(0, "Kierunek PCA", vx, dirStart, dirEnd, vy, dirStart, dirEnd, false) +
                scatterSeries(1, "Oś odniesienia 0°", rx, refStart, refEnd, ry, refStart, refEnd, true) +
                scatterSeries(2, "Łuk theta", ax, arcStart, arcEnd, ay, arcStart, arcEnd, false) +

                "<c:axId val=\"" + xAxis + "\"/><c:axId val=\"" + yAxis + "\"/>" +
                "</c:scatterChart>" +
                valueAxis(xAxis, yAxis, "b") +
                valueAxis(yAxis, xAxis, "l") +
                "</c:plotArea>" +
                "<c:legend><c:legendPos val=\"b\"/><c:layout/></c:legend>" +
                "<c:plotVisOnly val=\"1\"/><c:dispBlanksAs val=\"gap\"/>" +
                "</c:chart>" +
                "</c:chartSpace>";
    }

    private static String chartTitle(String title) {
        return "<c:title><c:tx><c:rich>" +
                "<a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang=\"pl-PL\" sz=\"1200\" b=\"1\"/>" +
                "<a:t>" + xml(title) + "</a:t></a:r></a:p>" +
                "</c:rich></c:tx><c:layout/><c:overlay val=\"0\"/></c:title>";
    }

    private static String scatterSeries(int idx, String name,
                                        String xCol, int x1, int x2,
                                        String yCol, int y1, int y2,
                                        boolean dashed) {
        String style = dashed
                ? "<c:spPr><a:ln w=\"12700\"><a:prstDash val=\"dash\"/></a:ln></c:spPr>"
                : "";

        return "<c:ser>" +
                "<c:idx val=\"" + idx + "\"/><c:order val=\"" + idx + "\"/>" +
                "<c:tx><c:v>" + xml(name) + "</c:v></c:tx>" +
                "<c:marker><c:symbol val=\"circle\"/><c:size val=\"4\"/></c:marker>" +
                style +
                "<c:xVal><c:numRef><c:f>'Kierunki'!$" + xCol + "$" + x1 + ":$" + xCol + "$" + x2 + "</c:f></c:numRef></c:xVal>" +
                "<c:yVal><c:numRef><c:f>'Kierunki'!$" + yCol + "$" + y1 + ":$" + yCol + "$" + y2 + "</c:f></c:numRef></c:yVal>" +
                "<c:smooth val=\"0\"/>" +
                "</c:ser>";
    }

    private static String valueAxis(long id, long cross, String pos) {
        return "<c:valAx>" +
                "<c:axId val=\"" + id + "\"/>" +
                "<c:scaling><c:orientation val=\"minMax\"/><c:max val=\"1.1\"/><c:min val=\"-1.1\"/></c:scaling>" +
                "<c:delete val=\"0\"/><c:axPos val=\"" + pos + "\"/>" +
                "<c:majorGridlines/><c:numFmt formatCode=\"0.00\" sourceLinked=\"0\"/>" +
                "<c:majorTickMark val=\"out\"/><c:minorTickMark val=\"none\"/>" +
                "<c:tickLblPos val=\"nextTo\"/>" +
                "<c:crossAx val=\"" + cross + "\"/><c:crosses val=\"autoZero\"/>" +
                "<c:crossBetween val=\"midCat\"/>" +
                "</c:valAx>";
    }

    private static String directionSheetRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing\" Target=\"../drawings/drawing1.xml\"/>" +
                "</Relationships>";
    }

    private static String drawing() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<xdr:wsDr xmlns:xdr=\"http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing\" " +
                "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
                "xmlns:c=\"http://schemas.openxmlformats.org/drawingml/2006/chart\">" +
                chartAnchor(0, 0, 7, 28, 2, "Wykres kierunku XY", "rId1") +
                chartAnchor(7, 0, 14, 28, 3, "Wykres kierunku XZ", "rId2") +
                chartAnchor(0, 28, 7, 56, 4, "Wykres kierunku YZ", "rId3") +
                "</xdr:wsDr>";
    }

    private static String chartAnchor(int col1, int row1, int col2, int row2,
                                      int id, String name, String relId) {
        return "<xdr:twoCellAnchor>" +
                "<xdr:from><xdr:col>" + col1 + "</xdr:col><xdr:colOff>0</xdr:colOff>" +
                "<xdr:row>" + row1 + "</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>" +
                "<xdr:to><xdr:col>" + col2 + "</xdr:col><xdr:colOff>0</xdr:colOff>" +
                "<xdr:row>" + row2 + "</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>" +
                "<xdr:graphicFrame macro=\"\">" +
                "<xdr:nvGraphicFramePr><xdr:cNvPr id=\"" + id + "\" name=\"" + xml(name) + "\"/>" +
                "<xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr>" +
                "<xdr:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"0\" cy=\"0\"/></xdr:xfrm>" +
                "<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/chart\">" +
                "<c:chart r:id=\"" + relId + "\"/></a:graphicData></a:graphic>" +
                "</xdr:graphicFrame><xdr:clientData/>" +
                "</xdr:twoCellAnchor>";
    }

    private static String drawingRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart\" Target=\"../charts/chart1.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart\" Target=\"../charts/chart2.xml\"/>" +
                "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart\" Target=\"../charts/chart3.xml\"/>" +
                "</Relationships>";
    }

    private static final class Cell {
        final boolean numeric;
        final String value;
        final boolean header;
        Cell(boolean numeric, String value, boolean header) {
            this.numeric = numeric;
            this.value = value;
            this.header = header;
        }
    }

    private static Cell str(String s, boolean header) {
        return new Cell(false, s == null ? "" : s, header);
    }

    private static Cell num(double v) {
        return new Cell(true, String.format(Locale.US, "%.12g", v), false);
    }

    private static void row(OutputStreamWriter w, int r, Cell[] cells) throws IOException {
        w.write("<row r=\"");
        w.write(Integer.toString(r));
        w.write("\">");

        for (int c = 0; c < cells.length; c++) {
            Cell cell = cells[c];
            if (cell == null) cell = str("", false);
            String ref = col(c + 1) + r;

            if (cell.numeric) {
                w.write("<c r=\"");
                w.write(ref);
                w.write("\"><v>");
                w.write(cell.value);
                w.write("</v></c>");
            } else {
                w.write("<c r=\"");
                w.write(ref);
                w.write("\" t=\"inlineStr\"");
                if (cell.header) w.write(" s=\"1\"");
                w.write("><is><t xml:space=\"preserve\">");
                w.write(xml(cell.value));
                w.write("</t></is></c>");
            }
        }
        w.write("</row>");
    }

    private static String col(int index) {
        StringBuilder s = new StringBuilder();
        int n = index;
        while (n > 0) {
            n--;
            s.insert(0, (char)('A' + (n % 26)));
            n /= 26;
        }
        return s.toString();
    }

    private static void text(ZipOutputStream zip, String path, String value) throws IOException {
        zip.putNextEntry(new ZipEntry(path));
        zip.write(value.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private static String xml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }

    private static String contentTypes() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet3.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/drawings/drawing1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.drawing+xml\"/>" +
                "<Override PartName=\"/xl/charts/chart1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.drawingml.chart+xml\"/>" +
                "<Override PartName=\"/xl/charts/chart2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.drawingml.chart+xml\"/>" +
                "<Override PartName=\"/xl/charts/chart3.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.drawingml.chart+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>" +
                "<Override PartName=\"/docProps/app.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.extended-properties+xml\"/>" +
                "</Types>";
    }

    private static String rootRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>" +
                "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties\" Target=\"docProps/app.xml\"/>" +
                "</Relationships>";
    }

    private static String workbook() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                "<sheets>" +
                "<sheet name=\"Podsumowanie\" sheetId=\"1\" r:id=\"rId1\"/>" +
                "<sheet name=\"Dane_1\" sheetId=\"2\" r:id=\"rId2\"/>" +
                "<sheet name=\"Kierunki\" sheetId=\"3\" r:id=\"rId3\"/>" +
                "</sheets></workbook>";
    }

    private static String workbookRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet2.xml\"/>" +
                "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet3.xml\"/>" +
                "<Relationship Id=\"rId4\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
                "</Relationships>";
    }

    private static String styles() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                "<fonts count=\"2\">" +
                "<font><sz val=\"11\"/><name val=\"Calibri\"/></font>" +
                "<font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font>" +
                "</fonts>" +
                "<fills count=\"1\"><fill><patternFill patternType=\"none\"/></fill></fills>" +
                "<borders count=\"1\"><border/></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"2\">" +
                "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>" +
                "</cellXfs>" +
                "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>" +
                "</styleSheet>";
    }

    private static String coreProps() {
        String now = OffsetDateTime.now().toString();
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" " +
                "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
                "xmlns:dcterms=\"http://purl.org/dc/terms/\" " +
                "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
                "<dc:creator>ADXL345 PRO Android V6.6</dc:creator>" +
                "<cp:lastModifiedBy>ADXL345 PRO Android V6.6</cp:lastModifiedBy>" +
                "<dcterms:created xsi:type=\"dcterms:W3CDTF\">" + xml(now) + "</dcterms:created>" +
                "</cp:coreProperties>";
    }

    private static String appProps() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Properties xmlns=\"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties\" " +
                "xmlns:vt=\"http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes\">" +
                "<Application>ADXL345 PRO Android V6.6</Application>" +
                "</Properties>";
    }
}

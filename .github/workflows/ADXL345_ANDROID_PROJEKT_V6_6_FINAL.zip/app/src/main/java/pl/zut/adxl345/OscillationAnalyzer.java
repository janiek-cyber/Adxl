package pl.zut.adxl345;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * ADXL345 PRO V6.6.
 * Analiza harmoniczna + niezależny kierunek PCA LIVE.
 */
final class OscillationAnalyzer {
    static final double G0 = 9.80665;
    static final int MIN_SAMPLES = 40;
    static final double LIVE_DIRECTION_WINDOW_S = 0.75;
    static final double MIN_DIRECTION_RMS_G = 0.015;
    static final double DIRECTION_RELIABLE_PCT = 55.0;
    static final double HARMONIC_RELIABLE_PCT = 60.0;

    static final class Sample {
        final double t, x, y, z;
        Sample(double t, double x, double y, double z) {
            this.t=t; this.x=x; this.y=y; this.z=z;
        }
    }

    static final class Result {
        final double frequencyHz, accelPeakG, amplitudeMm, strokePpMm;
        final double qualityPct, sampleRateHz;
        final double dirX, dirY, dirZ;
        Result(double frequencyHz, double accelPeakG, double amplitudeMm,
               double strokePpMm, double qualityPct, double sampleRateHz,
               double dirX, double dirY, double dirZ) {
            this.frequencyHz=frequencyHz; this.accelPeakG=accelPeakG;
            this.amplitudeMm=amplitudeMm; this.strokePpMm=strokePpMm;
            this.qualityPct=qualityPct; this.sampleRateHz=sampleRateHz;
            this.dirX=dirX; this.dirY=dirY; this.dirZ=dirZ;
        }
        boolean reliable() { return qualityPct >= HARMONIC_RELIABLE_PCT; }
    }

    static final class DirectionResult {
        final double dirX, dirY, dirZ;
        final double gravityX, gravityY, gravityZ;
        final double dominancePct, rmsDynamicG;
        final double angleFromHorizontalDeg, angleFromVerticalDeg;
        final double angleToLongitudinalDeg, lateralDeviationDeg;
        final double angleXYDeg, angleXZDeg, angleYZDeg;
        final double longitudinalComponent, verticalComponent, transverseComponent;
        final String longitudinalAxis;

        DirectionResult(double dirX, double dirY, double dirZ,
                        double gravityX, double gravityY, double gravityZ,
                        double dominancePct, double rmsDynamicG,
                        double angleFromHorizontalDeg, double angleFromVerticalDeg,
                        double angleToLongitudinalDeg, double lateralDeviationDeg,
                        double angleXYDeg, double angleXZDeg, double angleYZDeg,
                        double longitudinalComponent, double verticalComponent,
                        double transverseComponent, String longitudinalAxis) {
            this.dirX=dirX; this.dirY=dirY; this.dirZ=dirZ;
            this.gravityX=gravityX; this.gravityY=gravityY; this.gravityZ=gravityZ;
            this.dominancePct=dominancePct; this.rmsDynamicG=rmsDynamicG;
            this.angleFromHorizontalDeg=angleFromHorizontalDeg;
            this.angleFromVerticalDeg=angleFromVerticalDeg;
            this.angleToLongitudinalDeg=angleToLongitudinalDeg;
            this.lateralDeviationDeg=lateralDeviationDeg;
            this.angleXYDeg=angleXYDeg; this.angleXZDeg=angleXZDeg; this.angleYZDeg=angleYZDeg;
            this.longitudinalComponent=longitudinalComponent;
            this.verticalComponent=verticalComponent;
            this.transverseComponent=transverseComponent;
            this.longitudinalAxis=longitudinalAxis;
        }
        boolean reliable() { return dominancePct >= DIRECTION_RELIABLE_PCT; }
    }

    private static final class Fit {
        final double sse; final double[] coef;
        Fit(double sse, double[] coef) { this.sse=sse; this.coef=coef; }
    }

    static DirectionResult analyzeDirection(List<Sample> input, String longitudinalAxis) {
        if (input == null || input.size() < MIN_SAMPLES) return null;
        ArrayList<Sample> all = cleanSorted(input);
        if (all.size() < MIN_SAMPLES) return null;

        double lastT = all.get(all.size()-1).t;
        ArrayList<Sample> samples = new ArrayList<>();
        for (Sample s : all) if (lastT - s.t <= LIVE_DIRECTION_WINDOW_S) samples.add(s);
        if (samples.size() < MIN_SAMPLES) return null;

        int n=samples.size();
        double[] g={0,0,0};
        for(Sample s:samples){ g[0]+=s.x; g[1]+=s.y; g[2]+=s.z; }
        g[0]/=n; g[1]/=n; g[2]/=n;

        double[][] cov=new double[3][3];
        for(Sample s:samples){
            double[] d={s.x-g[0],s.y-g[1],s.z-g[2]};
            for(int a=0;a<3;a++) for(int b=0;b<3;b++) cov[a][b]+=d[a]*d[b];
        }
        double div=Math.max(1,n-1);
        for(int a=0;a<3;a++) for(int b=0;b<3;b++) cov[a][b]/=div;

        double[] u=principalEigenvector(cov);
        if(u==null) return null;
        double lambda=quadratic(cov,u);
        double total=Math.max(0,cov[0][0])+Math.max(0,cov[1][1])+Math.max(0,cov[2][2]);
        if(!finite(lambda)||!finite(total)||total<=1e-10) return null;
        double rms=Math.sqrt(Math.max(0,lambda));
        if(rms<MIN_DIRECTION_RMS_G) return null;
        double dominance=100.0*lambda/total;

        return directionMetrics(u,g,longitudinalAxis,dominance,rms);
    }

    static Result analyze(List<Sample> input, double fMinHz, double fMaxHz) {
        if (input == null || input.size() < MIN_SAMPLES) return null;
        ArrayList<Sample> samples=cleanSorted(input);
        if(samples.size()<MIN_SAMPLES) return null;

        int n=samples.size();
        double t0=samples.get(0).t, t1=samples.get(n-1).t;
        double duration=t1-t0;
        if(!(duration>0)) return null;

        ArrayList<Double> dts=new ArrayList<>();
        for(int i=1;i<n;i++){
            double dt=samples.get(i).t-samples.get(i-1).t;
            if(dt>1e-6&&finite(dt)) dts.add(dt);
        }
        if(dts.size()<MIN_SAMPLES/2) return null;
        Collections.sort(dts);
        double medianDt=dts.get(dts.size()/2);
        if(!(medianDt>0)) return null;
        double fs=1.0/medianDt;

        double[] t=new double[n];
        double[][] xyz=new double[n][3];
        double meanT=0;
        for(int i=0;i<n;i++){
            Sample s=samples.get(i); t[i]=s.t;
            xyz[i][0]=s.x; xyz[i][1]=s.y; xyz[i][2]=s.z; meanT+=s.t;
        }
        meanT/=n;

        double[][] d=new double[n][3];
        for(int axis=0;axis<3;axis++){
            double sy=0,st=0,stt=0,sty=0;
            for(int i=0;i<n;i++){
                double tc=t[i]-meanT, yy=xyz[i][axis];
                sy+=yy; st+=tc; stt+=tc*tc; sty+=tc*yy;
            }
            double denom=n*stt-st*st;
            double slope=Math.abs(denom)<1e-18?0:(n*sty-st*sy)/denom;
            double intercept=(sy-slope*st)/n;
            for(int i=0;i<n;i++) d[i][axis]=xyz[i][axis]-(intercept+slope*(t[i]-meanT));
        }

        double[][] cov=new double[3][3];
        for(int i=0;i<n;i++) for(int a=0;a<3;a++) for(int b=0;b<3;b++) cov[a][b]+=d[i][a]*d[i][b];
        double div=Math.max(1,n-1);
        for(int a=0;a<3;a++) for(int b=0;b<3;b++) cov[a][b]/=div;
        double[] dir=principalEigenvector(cov);
        if(dir==null) return null;

        double[] y=new double[n];
        double meanY=0;
        for(int i=0;i<n;i++) { y[i]=d[i][0]*dir[0]+d[i][1]*dir[1]+d[i][2]*dir[2]; meanY+=y[i]; }
        meanY/=n;
        double sumSq=0;
        for(int i=0;i<n;i++){ y[i]-=meanY; sumSq+=y[i]*y[i]; }
        double rms=Math.sqrt(sumSq/n);
        if(!finite(rms)||rms<0.002) return null;

        double fMin=Math.max(fMinHz,2.0/duration);
        double fMax=Math.min(fMaxHz,0.45*fs);
        if(!(fMax>fMin)||fMin<=0) return null;

        double coarseStep=Math.max(0.03,1.0/(duration*6.0));
        int coarseCount=(int)Math.ceil((fMax-fMin)/coarseStep)+1;
        if(coarseCount>1800){ coarseStep=(fMax-fMin)/1799.0; coarseCount=1800; }
        double bestF=fMin,bestPower=-1;
        for(int k=0;k<coarseCount;k++){
            double f=Math.min(fMax,fMin+k*coarseStep), omega=2*Math.PI*f;
            double ss=0,cc=0,ys=0,yc=0;
            for(int i=0;i<n;i++){
                double ph=omega*(t[i]-t0), sn=Math.sin(ph), cs=Math.cos(ph);
                ss+=sn*sn; cc+=cs*cs; ys+=y[i]*sn; yc+=y[i]*cs;
            }
            double power=ys*ys/Math.max(ss,1e-12)+yc*yc/Math.max(cc,1e-12);
            if(power>bestPower){bestPower=power;bestF=f;}
        }

        Fit bestFit=null;
        double half=coarseStep;
        for(int pass=0;pass<3;pass++){
            double lo=Math.max(fMin,bestF-half),hi=Math.min(fMax,bestF+half);
            for(int k=0;k<=20;k++){
                double f=lo+(hi-lo)*k/20.0;
                Fit fit=fitSineTrend(t,y,meanT,t0,f);
                if(fit!=null&&(bestFit==null||fit.sse<bestFit.sse)){bestFit=fit;bestF=f;}
            }
            half=Math.max(half/8.0,1e-5);
        }
        if(bestFit==null||!(bestF>0)) return null;

        double accelPeakG=Math.hypot(bestFit.coef[0],bestFit.coef[1]);
        if(!finite(accelPeakG)||accelPeakG<0.002) return null;
        double sst=0; for(double v:y) sst+=v*v;
        double r2=sst<=1e-18?0:1.0-bestFit.sse/sst;
        double quality=Math.max(0,Math.min(100,100*r2));

        double omega=2*Math.PI*bestF;
        double amplitudeMm=(accelPeakG*G0)/(omega*omega)*1000.0;
        double strokePpMm=2.0*amplitudeMm;
        if(!finite(amplitudeMm)||!finite(strokePpMm)) return null;

        return new Result(bestF,accelPeakG,amplitudeMm,strokePpMm,quality,fs,dir[0],dir[1],dir[2]);
    }

    private static DirectionResult directionMetrics(double[] direction,double[] gravity,String axisName,double dominance,double rms){
        double[] u=unit(direction), g=unit(gravity);
        if(u==null||g==null) return null;
        String axis=(axisName==null?"X":axisName.trim().toUpperCase());
        double[] sensorLong=axis.equals("Y")?new double[]{0,1,0}:axis.equals("Z")?new double[]{0,0,1}:new double[]{1,0,0};

        double dg=dot(sensorLong,g);
        double[] longH={sensorLong[0]-dg*g[0],sensorLong[1]-dg*g[1],sensorLong[2]-dg*g[2]};
        longH=unit(longH);

        double verticalAbs=clamp(Math.abs(dot(u,g)),0,1);
        double angleFromHorizontal=Math.toDegrees(Math.asin(verticalAbs));
        double angleFromVertical=90.0-angleFromHorizontal;

        double cLong=Double.NaN,cVert=dot(u,g),cTrans=Double.NaN;
        double angleToLong=Double.NaN,lateral=Double.NaN;
        if(longH!=null){
            double[] trans=unit(cross(g,longH));
            if(trans!=null){
                if(dot(u,longH)<0){u[0]*=-1;u[1]*=-1;u[2]*=-1;}
                cVert=dot(u,g); cLong=dot(u,longH); cTrans=dot(u,trans);
                angleToLong=Math.toDegrees(Math.acos(clamp(Math.abs(cLong),0,1)));
                lateral=Math.toDegrees(Math.atan2(Math.abs(cTrans),Math.hypot(cLong,cVert)));
            }
        }

        return new DirectionResult(
                u[0],u[1],u[2],g[0],g[1],g[2],dominance,rms,
                angleFromHorizontal,angleFromVertical,angleToLong,lateral,
                planeTilt(u[0],u[1]),planeTilt(u[0],u[2]),planeTilt(u[1],u[2]),
                cLong,cVert,cTrans,axis);
    }

    private static double planeTilt(double a,double b){
        if(!finite(a)||!finite(b)||(Math.abs(a)<1e-12&&Math.abs(b)<1e-12)) return Double.NaN;
        double ang=Math.toDegrees(Math.atan2(b,a));
        while(ang>90) ang-=180;
        while(ang<=-90) ang+=180;
        return ang;
    }

    private static ArrayList<Sample> cleanSorted(List<Sample> input){
        ArrayList<Sample> s=new ArrayList<>();
        for(Sample v:input) if(v!=null&&finite(v.t)&&finite(v.x)&&finite(v.y)&&finite(v.z)) s.add(v);
        s.sort((a,b)->Double.compare(a.t,b.t)); return s;
    }

    private static double[] principalEigenvector(double[][] cov){
        double[] u={1,1,1}; normalize3(u);
        for(int it=0;it<50;it++){
            double[] v={
                    cov[0][0]*u[0]+cov[0][1]*u[1]+cov[0][2]*u[2],
                    cov[1][0]*u[0]+cov[1][1]*u[1]+cov[1][2]*u[2],
                    cov[2][0]*u[0]+cov[2][1]*u[1]+cov[2][2]*u[2]};
            if(norm3(v)<1e-15) return null; normalize3(v); u=v;
        }
        return u;
    }

    private static double quadratic(double[][] a,double[] u){
        return u[0]*(a[0][0]*u[0]+a[0][1]*u[1]+a[0][2]*u[2])+
               u[1]*(a[1][0]*u[0]+a[1][1]*u[1]+a[1][2]*u[2])+
               u[2]*(a[2][0]*u[0]+a[2][1]*u[1]+a[2][2]*u[2]);
    }

    private static Fit fitSineTrend(double[] t,double[] y,double meanT,double t0,double f){
        int n=t.length; double[][] a=new double[4][4]; double[] b=new double[4]; double omega=2*Math.PI*f;
        for(int i=0;i<n;i++){
            double ph=omega*(t[i]-t0); double[] v={Math.sin(ph),Math.cos(ph),1,t[i]-meanT};
            for(int r=0;r<4;r++){ b[r]+=v[r]*y[i]; for(int c=0;c<4;c++) a[r][c]+=v[r]*v[c]; }
        }
        double[] coef=solve4(a,b); if(coef==null)return null;
        double sse=0;
        for(int i=0;i<n;i++){
            double ph=omega*(t[i]-t0);
            double pred=coef[0]*Math.sin(ph)+coef[1]*Math.cos(ph)+coef[2]+coef[3]*(t[i]-meanT);
            double e=y[i]-pred;sse+=e*e;
        }
        return new Fit(sse,coef);
    }

    private static double[] solve4(double[][] aIn,double[] bIn){
        double[][] m=new double[4][5];
        for(int r=0;r<4;r++){System.arraycopy(aIn[r],0,m[r],0,4);m[r][4]=bIn[r];}
        for(int col=0;col<4;col++){
            int pivot=col; for(int r=col+1;r<4;r++) if(Math.abs(m[r][col])>Math.abs(m[pivot][col])) pivot=r;
            if(Math.abs(m[pivot][col])<1e-14)return null;
            if(pivot!=col){double[] tmp=m[pivot];m[pivot]=m[col];m[col]=tmp;}
            double div=m[col][col]; for(int c=col;c<5;c++)m[col][c]/=div;
            for(int r=0;r<4;r++) if(r!=col){double fac=m[r][col];for(int c=col;c<5;c++)m[r][c]-=fac*m[col][c];}
        }
        return new double[]{m[0][4],m[1][4],m[2][4],m[3][4]};
    }

    private static double clamp(double v,double lo,double hi){return Math.max(lo,Math.min(hi,v));}
    private static double dot(double[] a,double[] b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
    private static double[] cross(double[] a,double[] b){return new double[]{a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]};}
    private static double[] unit(double[] v){double n=norm3(v);if(!finite(n)||n<1e-12)return null;return new double[]{v[0]/n,v[1]/n,v[2]/n};}
    private static boolean finite(double v){return !Double.isNaN(v)&&!Double.isInfinite(v);}
    private static double norm3(double[] v){return Math.sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);}
    private static void normalize3(double[] v){double n=norm3(v);if(n<=0)return;v[0]/=n;v[1]/=n;v[2]/=n;}
}

package pl.zut.adxl345;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Lekki wykres bez zewnętrznych bibliotek. */
public class SimpleLineChartView extends View {
    private static final double WINDOW_S = 10.0;
    private final Object lock = new Object();
    private final ArrayList<Point> points = new ArrayList<>();
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint axis = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint px = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint py = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pz = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pm = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);

    private static final class Point {
        final double t, x, y, z, m;
        Point(double t, double x, double y, double z, double m) {
            this.t=t; this.x=x; this.y=y; this.z=z; this.m=m;
        }
    }

    public SimpleLineChartView(Context c) { super(c); init(); }
    public SimpleLineChartView(Context c, AttributeSet a) { super(c,a); init(); }
    public SimpleLineChartView(Context c, AttributeSet a, int s) { super(c,a,s); init(); }

    private void init() {
        setBackgroundColor(Color.WHITE);
        grid.setColor(0xFFE0E0E0); grid.setStrokeWidth(dp(1));
        axis.setColor(0xFF666666); axis.setStrokeWidth(dp(1)); axis.setStyle(Paint.Style.STROKE);
        px.setColor(0xFFD32F2F); px.setStrokeWidth(dp(1.5f)); px.setStyle(Paint.Style.STROKE);
        py.setColor(0xFF1976D2); py.setStrokeWidth(dp(1.5f)); py.setStyle(Paint.Style.STROKE);
        pz.setColor(0xFF388E3C); pz.setStrokeWidth(dp(1.5f)); pz.setStyle(Paint.Style.STROKE);
        pm.setColor(0xFF6A1B9A); pm.setStrokeWidth(dp(1.8f)); pm.setStyle(Paint.Style.STROKE);
        text.setColor(0xFF333333); text.setTextSize(dp(12));
    }

    public void clear() {
        synchronized (lock) { points.clear(); }
        postInvalidate();
    }

    public void add(double t, double x, double y, double z, double mag) {
        synchronized (lock) {
            points.add(new Point(t,x,y,z,mag));
            double cutoff = t - WINDOW_S;
            while (!points.isEmpty() && points.get(0).t < cutoff) points.remove(0);
            if (points.size() > 2000) points.subList(0, points.size()-2000).clear();
        }
        postInvalidateOnAnimation();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        List<Point> data;
        synchronized (lock) { data = new ArrayList<>(points); }
        int w=getWidth(), h=getHeight();
        float l=dp(46), r=w-dp(10), top=dp(24), b=h-dp(28);
        if (r<=l || b<=top) return;

        for(int i=0;i<=4;i++) {
            float yy=top+(b-top)*i/4f;
            c.drawLine(l,yy,r,yy,grid);
        }
        for(int i=0;i<=5;i++) {
            float xx=l+(r-l)*i/5f;
            c.drawLine(xx,top,xx,b,grid);
        }
        c.drawRect(l,top,r,b,axis);

        if (data.size()<2) {
            c.drawText("Brak danych", l+dp(8), top+dp(20), text);
            return;
        }
        double rightT=data.get(data.size()-1).t;
        double leftT=Math.max(0,rightT-WINDOW_S);
        double lo=Double.POSITIVE_INFINITY, hi=Double.NEGATIVE_INFINITY;
        for(Point p:data){
            lo=Math.min(lo,Math.min(Math.min(p.x,p.y),Math.min(p.z,p.m)));
            hi=Math.max(hi,Math.max(Math.max(p.x,p.y),Math.max(p.z,p.m)));
        }
        if(!Double.isFinite(lo)||!Double.isFinite(hi)) return;
        double span=Math.max(0.2,hi-lo), margin=0.12*span;
        lo-=margin; hi+=margin;
        drawSeries(c,data,l,r,top,b,leftT,rightT,lo,hi,0,px);
        drawSeries(c,data,l,r,top,b,leftT,rightT,lo,hi,1,py);
        drawSeries(c,data,l,r,top,b,leftT,rightT,lo,hi,2,pz);
        drawSeries(c,data,l,r,top,b,leftT,rightT,lo,hi,3,pm);

        c.drawText(String.format(java.util.Locale.US,"%.2f g",hi), dp(3), top+dp(4), text);
        c.drawText(String.format(java.util.Locale.US,"%.2f g",lo), dp(3), b, text);
        c.drawText("X", l+dp(8), dp(16), px);
        c.drawText("Y", l+dp(34), dp(16), py);
        c.drawText("Z", l+dp(60), dp(16), pz);
        c.drawText("|a|", l+dp(86), dp(16), pm);
    }

    private void drawSeries(Canvas c,List<Point> d,float l,float r,float top,float b,
                            double t0,double t1,double lo,double hi,int which,Paint p){
        boolean have=false; float px0=0,py0=0;
        double dt=Math.max(1e-9,t1-t0);
        for(Point q:d){
            if(q.t<t0) continue;
            double v=which==0?q.x:which==1?q.y:which==2?q.z:q.m;
            float x=(float)(l+(q.t-t0)/dt*(r-l));
            float y=(float)(b-(v-lo)/(hi-lo)*(b-top));
            if(have) c.drawLine(px0,py0,x,y,p);
            px0=x; py0=y; have=true;
        }
    }

    private float dp(float v){ return v*getResources().getDisplayMetrics().density; }
}

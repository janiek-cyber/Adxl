package pl.zut.adxl345;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;
import com.hoho.android.usbserial.util.SerialInputOutputManager;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity implements SerialInputOutputManager.Listener {
    private static final String ACTION_USB_PERMISSION="pl.zut.adxl345.USB_PERMISSION";
    private static final double UI_UPDATE_SECONDS=0.08;
    private static final double ANALYSIS_UPDATE_SECONDS=0.25;
    private static final double KALMAN_Q=0.001, KALMAN_R=0.01;
    private static final String NUMBER="[-+]?(?:\\d+(?:[.,]\\d*)?|[.,]\\d+)(?:[eE][-+]?\\d+)?";
    private static final Pattern XYZ_PATTERN=Pattern.compile(
            "[Xx]\\s*[:=]\\s*("+NUMBER+").*?"+
            "[Yy]\\s*[:=]\\s*("+NUMBER+").*?"+
            "[Zz]\\s*[:=]\\s*("+NUMBER+")");

    private UsbManager usbManager;
    private final List<PortEntry> portEntries=new ArrayList<>();
    private UsbSerialPort serialPort;
    private UsbDeviceConnection usbConnection;
    private SerialInputOutputManager ioManager;
    private PortEntry pendingPermissionEntry;
    private boolean connected=false;

    private Spinner deviceSpinner,baudSpinner,axisSpinner;
    private Button refreshButton,connectButton,startButton,stopButton;
    private EditText scaleEdit,fminEdit,fmaxEdit,windowEdit;
    private CheckBox kalmanCheck;
    private TextView statusText,currentValues,frequencyText,accelText,strokeText,qualityText,directionText,fileText,statsText;
    private SimpleLineChartView chart;
    private VectorAngleView vectorView;

    private final Object stateLock=new Object();
    private volatile boolean sessionActive=false;
    private volatile Settings activeSettings;
    private volatile boolean kalmanEnabled=false;
    private SessionRecorder recorder;
    private long sessionGeneration=0;
    private double sessionStartTime=Double.NaN;
    private double lastUiTime=Double.NaN,lastAnalysisSchedule=Double.NaN;
    private long sampleCount=0,badLineCount=0;
    private double[] reference=null;

    private Kalman1D kx=new Kalman1D(KALMAN_Q,KALMAN_R),ky=new Kalman1D(KALMAN_Q,KALMAN_R),kz=new Kalman1D(KALMAN_Q,KALMAN_R);
    private final ArrayDeque<OscillationAnalyzer.Sample> oscBuffer=new ArrayDeque<>();
    private volatile OscillationAnalyzer.Result currentOsc;
    private volatile OscillationAnalyzer.DirectionResult currentDirection;

    private final ExecutorService analysisExecutor=Executors.newSingleThreadExecutor();
    private final ExecutorService exportExecutor=Executors.newSingleThreadExecutor();
    private final AtomicBoolean analysisRunning=new AtomicBoolean(false);
    private final StringBuilder serialTextBuffer=new StringBuilder();

    // RP2040 micros() 32-bit unwrap.
    private long lastRawUs=-1,wrapUs=0,startAbsUs=-1;
    private boolean usingDeviceClock=false;

    private final DateTimeFormatter fileStamp=DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS",Locale.US);
    private final DateTimeFormatter isoStamp=DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS",Locale.US);

    private final BroadcastReceiver permissionReceiver=new BroadcastReceiver(){
        @Override public void onReceive(Context context,Intent intent){
            if(!ACTION_USB_PERMISSION.equals(intent.getAction()))return;
            PortEntry entry=pendingPermissionEntry;pendingPermissionEntry=null;
            boolean granted=intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED,false);
            if(granted&&entry!=null)openPort(entry);else setStatus("Brak zgody Androida na dostęp do USB.");
        }
    };

    private static final class PortEntry {
        final UsbSerialDriver driver; final int portIndex; final String label;
        PortEntry(UsbSerialDriver d,int i,String l){driver=d;portIndex=i;label=l;}
        @Override public String toString(){return label;}
    }
    private static final class Settings {
        final double scale,fmin,fmax,window; final String axis;
        Settings(double s,double a,double b,double w,String axis){scale=s;fmin=a;fmax=b;window=w;this.axis=axis;}
    }
    private static final class ParsedSample {
        final double x,y,z; final Long rawUs;
        ParsedSample(double x,double y,double z,Long rawUs){this.x=x;this.y=y;this.z=z;this.rawUs=rawUs;}
    }

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);setContentView(R.layout.activity_main);
        usbManager=(UsbManager)getSystemService(Context.USB_SERVICE);
        bindViews();setupUi();
        IntentFilter f=new IntentFilter(ACTION_USB_PERMISSION);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.TIRAMISU) registerReceiver(permissionReceiver,f,Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(permissionReceiver,f);
        refreshDevices();
    }

    private void bindViews(){
        deviceSpinner=findViewById(R.id.deviceSpinner);baudSpinner=findViewById(R.id.baudSpinner);axisSpinner=findViewById(R.id.axisSpinner);
        refreshButton=findViewById(R.id.refreshButton);connectButton=findViewById(R.id.connectButton);startButton=findViewById(R.id.startButton);stopButton=findViewById(R.id.stopButton);
        scaleEdit=findViewById(R.id.scaleEdit);fminEdit=findViewById(R.id.fminEdit);fmaxEdit=findViewById(R.id.fmaxEdit);windowEdit=findViewById(R.id.windowEdit);kalmanCheck=findViewById(R.id.kalmanCheck);
        statusText=findViewById(R.id.statusText);currentValues=findViewById(R.id.currentValues);frequencyText=findViewById(R.id.frequencyText);accelText=findViewById(R.id.accelText);strokeText=findViewById(R.id.strokeText);qualityText=findViewById(R.id.qualityText);directionText=findViewById(R.id.directionText);fileText=findViewById(R.id.fileText);statsText=findViewById(R.id.statsText);
        chart=findViewById(R.id.chart);vectorView=findViewById(R.id.vectorView);
    }

    private void setupUi(){
        String[] bauds={"9600","19200","38400","57600","115200","230400","460800","921600"};
        ArrayAdapter<String> ba=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,bauds);ba.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);baudSpinner.setAdapter(ba);baudSpinner.setSelection(4);
        ArrayAdapter<String> aa=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,new String[]{"X","Y","Z"});aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);axisSpinner.setAdapter(aa);axisSpinner.setSelection(0);
        kalmanCheck.setChecked(false);
        refreshButton.setOnClickListener(v->refreshDevices());
        connectButton.setOnClickListener(v->{if(connected)disconnect(true);else connectSelected();});
        startButton.setOnClickListener(v->startMeasurement());stopButton.setOnClickListener(v->stopMeasurement(true));
    }

    private void refreshDevices(){
        if(connected)return;portEntries.clear();
        List<UsbSerialDriver> drivers=UsbSerialProber.getDefaultProber().findAllDrivers(usbManager);
        for(UsbSerialDriver d:drivers){
            UsbDevice dev=d.getDevice();String base=String.format(Locale.US,"%s VID:%04X PID:%04X",d.getClass().getSimpleName().replace("SerialDriver",""),dev.getVendorId(),dev.getProductId());
            for(int p=0;p<d.getPorts().size();p++)portEntries.add(new PortEntry(d,p,base+" / port "+p));
        }
        ArrayList<String> labels=new ArrayList<>();for(PortEntry e:portEntries)labels.add(e.label);if(labels.isEmpty())labels.add("Brak urządzenia USB-Serial");
        ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,labels);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);deviceSpinner.setAdapter(a);
        setStatus(portEntries.isEmpty()?"Podłącz RP2040 przez USB-OTG i kliknij Odśwież.":"Znaleziono urządzenie. Kliknij Połącz.");
    }

    private void connectSelected(){
        int idx=deviceSpinner.getSelectedItemPosition();if(idx<0||idx>=portEntries.size()){toast("Brak urządzenia USB-Serial.");return;}
        PortEntry e=portEntries.get(idx);UsbDevice dev=e.driver.getDevice();
        if(!usbManager.hasPermission(dev)){
            pendingPermissionEntry=e;Intent intent=new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName());
            PendingIntent pi=PendingIntent.getBroadcast(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_MUTABLE);
            usbManager.requestPermission(dev,pi);setStatus("Czekam na zgodę Androida na USB…");
        }else openPort(e);
    }

    private void openPort(PortEntry e){
        try{
            int baud=Integer.parseInt(baudSpinner.getSelectedItem().toString());usbConnection=usbManager.openDevice(e.driver.getDevice());
            if(usbConnection==null)throw new IOException("Android nie otworzył urządzenia USB.");
            serialPort=e.driver.getPorts().get(e.portIndex);serialPort.open(usbConnection);serialPort.setParameters(baud,8,UsbSerialPort.STOPBITS_1,UsbSerialPort.PARITY_NONE);
            try{serialPort.setDTR(true);}catch(Exception ignored){}try{serialPort.setRTS(true);}catch(Exception ignored){}
            ioManager=new SerialInputOutputManager(serialPort,this);ioManager.start();connected=true;
            connectButton.setText("Rozłącz");startButton.setEnabled(true);stopButton.setEnabled(false);refreshButton.setEnabled(false);deviceSpinner.setEnabled(false);baudSpinner.setEnabled(false);
            setStatus("POŁĄCZONO @ "+baud+" baud – naciśnij START");
        }catch(Exception ex){closeSerial();setStatus("Błąd USB: "+ex.getMessage());alert("Błąd połączenia",ex.toString());}
    }

    private void disconnect(boolean user){if(sessionActive)stopMeasurement(user);closeSerial();connected=false;runOnUiThread(()->{connectButton.setText("Połącz");startButton.setEnabled(false);stopButton.setEnabled(false);refreshButton.setEnabled(true);deviceSpinner.setEnabled(true);baudSpinner.setEnabled(true);setStatus("Niepołączony");});}
    private void closeSerial(){try{if(ioManager!=null)ioManager.stop();}catch(Exception ignored){}ioManager=null;try{if(serialPort!=null)serialPort.close();}catch(Exception ignored){}serialPort=null;try{if(usbConnection!=null)usbConnection.close();}catch(Exception ignored){}usbConnection=null;synchronized(serialTextBuffer){serialTextBuffer.setLength(0);}}

    private Settings readSettings(boolean show){
        try{
            double scale=parseEdit(scaleEdit),fmin=parseEdit(fminEdit),fmax=parseEdit(fmaxEdit),window=parseEdit(windowEdit);String axis=axisSpinner.getSelectedItem().toString();
            if(scale==0||fmin<=0||fmax<=fmin||window<2)throw new IllegalArgumentException();return new Settings(scale,fmin,fmax,window,axis);
        }catch(Exception e){if(show)alert("Błędne ustawienia","Wymagane: skala ≠ 0, 0 < f min < f max, okno ≥ 2 s.");return null;}
    }
    private double parseEdit(EditText e){return Double.parseDouble(e.getText().toString().trim().replace(',','.'));}

    private void startMeasurement(){
        if(!connected){toast("Najpierw połącz RP2040.");return;}Settings s=readSettings(true);if(s==null)return;
        String base="ADXL345_"+LocalDateTime.now().format(fileStamp);
        try{
            SessionRecorder newRecorder=new SessionRecorder(this);newRecorder.start(base);
            synchronized(stateLock){
                recorder=newRecorder;activeSettings=s;kalmanEnabled=kalmanCheck.isChecked();sessionActive=true;sessionGeneration++;
                sessionStartTime=Double.NaN;lastUiTime=Double.NaN;lastAnalysisSchedule=Double.NaN;sampleCount=0;badLineCount=0;reference=null;
                kx=new Kalman1D(KALMAN_Q,KALMAN_R);ky=new Kalman1D(KALMAN_Q,KALMAN_R);kz=new Kalman1D(KALMAN_Q,KALMAN_R);
                oscBuffer.clear();currentOsc=null;currentDirection=null;lastRawUs=-1;wrapUs=0;startAbsUs=-1;usingDeviceClock=false;
                chart.clear();vectorView.clear();
            }
            resetOscUi();setConfigEnabled(false);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            startButton.setEnabled(false);stopButton.setEnabled(true);fileText.setText("ZAPIS OD START: "+base+".csv / .xlsx");setStatus("START – zapis 400 Hz aktywny");
        }catch(Exception e){alert("Błąd START",e.toString());}
    }

    private void stopMeasurement(boolean showResult){
        SessionRecorder toExport;long stoppedGeneration;
        synchronized(stateLock){if(!sessionActive&&recorder==null)return;sessionActive=false;toExport=recorder;recorder=null;stoppedGeneration=sessionGeneration;oscBuffer.clear();}
        startButton.setEnabled(connected);stopButton.setEnabled(false);setConfigEnabled(true);getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setStatus("STOP – pomiar zatrzymany | START GOTOWY | Excel tworzy się w tle");
        if(toExport!=null){
            fileText.setText("CSV zamknięty – tworzę XLSX w tle; możesz zrobić następny pomiar");
            SessionRecorder finalRecorder=toExport;
            exportExecutor.submit(()->{
                try{
                    SessionRecorder.ExportResult r=finalRecorder.finishAndExport();
                    runOnUiThread(()->{
                        if(r!=null&&!sessionActive&&sessionGeneration==stoppedGeneration){fileText.setText("Excel: "+r.xlsxLocation);setStatus("EKSPORT GOTOWY – START GOTOWY");}
                        if(showResult&&r!=null&&!sessionActive)toast("Zapis zakończony: "+r.xlsxLocation);
                    });
                }catch(Exception e){runOnUiThread(()->{if(!sessionActive)fileText.setText("Błąd XLSX: "+e.getMessage());});}
            });
        }
    }

    @Override public void onNewData(byte[] data){
        String chunk=new String(data,StandardCharsets.UTF_8);ArrayList<String> lines=new ArrayList<>();
        synchronized(serialTextBuffer){serialTextBuffer.append(chunk);int nl;while((nl=indexOfNewline(serialTextBuffer))>=0){String line=serialTextBuffer.substring(0,nl).trim();serialTextBuffer.delete(0,nl+1);if(!line.isEmpty())lines.add(line);}if(serialTextBuffer.length()>8192)serialTextBuffer.delete(0,serialTextBuffer.length()-4096);}
        double perf=System.nanoTime()/1e9;for(String line:lines)processLine(line,perf);
    }
    private static int indexOfNewline(StringBuilder b){for(int i=0;i<b.length();i++)if(b.charAt(i)=='\n')return i;return -1;}
    @Override public void onRunError(Exception e){runOnUiThread(()->{setStatus("Błąd USB: "+e.getMessage());disconnect(false);});}

    private void processLine(String line,double perfSec){
        ParsedSample ps=parseSample(line);
        synchronized(stateLock){
            if(!sessionActive)return;if(ps==null){badLineCount++;return;}Settings st=activeSettings;if(st==null)return;
            double t=sampleTime(ps.rawUs,perfSec);if(Double.isNaN(sessionStartTime))sessionStartTime=t;double rel=t-sessionStartTime;
            double xm=ps.x*st.scale,ym=ps.y*st.scale,zm=ps.z*st.scale;

            oscBuffer.addLast(new OscillationAnalyzer.Sample(t,xm,ym,zm));while(!oscBuffer.isEmpty()&&t-oscBuffer.peekFirst().t>st.window)oscBuffer.removeFirst();
            if((Double.isNaN(lastAnalysisSchedule)||t-lastAnalysisSchedule>=ANALYSIS_UPDATE_SECONDS)&&!analysisRunning.getAndSet(true)){
                lastAnalysisSchedule=t;ArrayList<OscillationAnalyzer.Sample> snap=new ArrayList<>(oscBuffer);
                analysisExecutor.submit(()->{try{currentDirection=OscillationAnalyzer.analyzeDirection(snap,st.axis);currentOsc=OscillationAnalyzer.analyze(snap,st.fmin,st.fmax);}finally{analysisRunning.set(false);}});
            }

            double x=kalmanEnabled?kx.update(xm):xm,y=kalmanEnabled?ky.update(ym):ym,z=kalmanEnabled?kz.update(zm):zm;
            double mag=Math.sqrt(xm*xm+ym*ym+zm*zm);if(reference==null)reference=new double[]{xm,ym,zm};double dx=xm-reference[0],dy=ym-reference[1],dz=zm-reference[2];double delta=Math.sqrt(dx*dx+dy*dy+dz*dz);

            SessionRecorder.DataRow row=new SessionRecorder.DataRow();row.timeIso=LocalDateTime.now().format(isoStamp);row.timeFromStart=rel;row.x=xm;row.y=ym;row.z=zm;row.mag=mag;row.delta=delta;row.deviceUs=ps.rawUs;row.osc=currentOsc;row.direction=currentDirection;
            try{if(recorder!=null)recorder.write(row);}catch(IOException e){SessionRecorder bad=recorder;recorder=null;if(bad!=null)bad.abort();sessionActive=false;runOnUiThread(()->alert("Błąd zapisu",e.toString()));return;}

            sampleCount++;OscillationAnalyzer.Result o=currentOsc;OscillationAnalyzer.DirectionResult d=currentDirection;
            if(Double.isNaN(lastUiTime)||t-lastUiTime>=UI_UPDATE_SECONDS){lastUiTime=t;long sc=sampleCount,bc=badLineCount;runOnUiThread(()->updateUi(rel,x,y,z,mag,delta,o,d,sc,bc));}
        }
    }

    private double sampleTime(Long rawUs,double perfSec){
        if(rawUs==null)return perfSec;long raw=rawUs&0xFFFFFFFFL;
        if(lastRawUs>=0&&raw<lastRawUs&&(lastRawUs-raw)>0x80000000L)wrapUs+=(1L<<32);
        lastRawUs=raw;long abs=wrapUs+raw;if(startAbsUs<0)startAbsUs=abs;usingDeviceClock=true;return (abs-startAbsUs)/1e6;
    }

    private void updateUi(double t,double x,double y,double z,double mag,double delta,OscillationAnalyzer.Result o,OscillationAnalyzer.DirectionResult d,long sc,long bc){
        currentValues.setText(String.format(Locale.US,"X: %+.4f g   Y: %+.4f g   Z: %+.4f g   |a|: %.4f g   Δa: %.4f g",x,y,z,mag,delta));chart.add(t,x,y,z,mag);
        if(o!=null){
            if(o.reliable()){
                frequencyText.setText(String.format(Locale.US,"Częstotliwość: %.3f Hz",o.frequencyHz));accelText.setText(String.format(Locale.US,"A przysp.: %.4f g    Amplituda: %.3f mm",o.accelPeakG,o.amplitudeMm));strokeText.setText(String.format(Locale.US,"SKOK P-P: %.3f mm",o.strokePpMm));
            }else{
                frequencyText.setText(String.format(Locale.US,"Częstotliwość: --  (kandydat %.2f Hz)",o.frequencyHz));accelText.setText("A przysp.: -- g    Amplituda: -- mm");strokeText.setText("SKOK P-P: -- mm  [NIEWIARYGODNY]");
            }
            qualityText.setText(String.format(Locale.US,"Jakość FFT: %.0f %%   Próbkowanie: %.1f Hz",o.qualityPct,o.sampleRateHz));
        }else{frequencyText.setText("Częstotliwość: -- Hz");accelText.setText("A przysp.: -- g    Amplituda: -- mm");strokeText.setText("SKOK P-P: -- mm");qualityText.setText("Jakość FFT: -- %");}

        if(d!=null){
            vectorView.setDirection(d);String suffix=d.reliable()?"":"  [NISKA PEWNOŚĆ]";
            directionText.setText(String.format(Locale.US,"PCA: [%.3f, %.3f, %.3f] | θXY=%+.1f°  θXZ=%+.1f°  θYZ=%+.1f° | od poziomu %.1f° | boczne %.1f° | dominacja %.0f%%%s",d.dirX,d.dirY,d.dirZ,d.angleXYDeg,d.angleXZDeg,d.angleYZDeg,d.angleFromHorizontalDeg,d.lateralDeviationDeg,d.dominancePct,suffix));
        }else{vectorView.clear();directionText.setText("PCA: brak wyraźnego kierunku (ruch < 0.015 g)");}
        statsText.setText("Próbki: "+sc+" | błędne: "+bc+" | zegar: "+(usingDeviceClock?"RP2040 T_us":"Android"));
    }

    private void setConfigEnabled(boolean e){scaleEdit.setEnabled(e);fminEdit.setEnabled(e);fmaxEdit.setEnabled(e);windowEdit.setEnabled(e);axisSpinner.setEnabled(e);kalmanCheck.setEnabled(e);}
    private void resetOscUi(){currentValues.setText("X: --   Y: --   Z: --   |a|: --   Δa: --");frequencyText.setText("Częstotliwość: -- Hz");accelText.setText("A przysp.: -- g    Amplituda: -- mm");strokeText.setText("SKOK P-P: -- mm");qualityText.setText("Jakość FFT: -- %");directionText.setText("PCA: --");}

    static ParsedSample parseSample(String line){
        if(line==null)return null;String s=line.trim();if(s.isEmpty())return null;
        Matcher m=XYZ_PATTERN.matcher(s);if(m.find())try{return new ParsedSample(toDouble(m.group(1)),toDouble(m.group(2)),toDouble(m.group(3)),parseTrailingUs(s));}catch(Exception ignored){}
        String sep=s.contains(";")?";":",";String[] p=s.split(Pattern.quote(sep));if(p.length>=3)try{Long us=p.length>=4?parseLongish(p[3]):null;return new ParsedSample(toDouble(p[0]),toDouble(p[1]),toDouble(p[2]),us);}catch(Exception ignored){}
        String[] ws=s.split("\\s+");if(ws.length>=3)try{Long us=ws.length>=4?parseLongish(ws[3]):null;return new ParsedSample(toDouble(ws[0]),toDouble(ws[1]),toDouble(ws[2]),us);}catch(Exception ignored){}
        return null;
    }
    private static Long parseTrailingUs(String s){Matcher m=Pattern.compile("(?:T|T_us|us)\\s*[:=]\\s*(\\d+)",Pattern.CASE_INSENSITIVE).matcher(s);return m.find()?Long.parseLong(m.group(1)):null;}
    private static Long parseLongish(String s){String q=s.trim();if(!q.matches("[-+]?\\d+(?:\\.0+)?"))return null;return (long)Double.parseDouble(q);}
    private static double toDouble(String s){return Double.parseDouble(s.trim().replace(',','.'));}

    private void setStatus(String s){statusText.setText(s);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void alert(String t,String m){new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("OK",null).show();}

    @Override protected void onDestroy(){
        try{unregisterReceiver(permissionReceiver);}catch(Exception ignored){}synchronized(stateLock){sessionActive=false;if(recorder!=null){recorder.abort();recorder=null;}}
        closeSerial();analysisExecutor.shutdownNow();exportExecutor.shutdown();super.onDestroy();
    }
}

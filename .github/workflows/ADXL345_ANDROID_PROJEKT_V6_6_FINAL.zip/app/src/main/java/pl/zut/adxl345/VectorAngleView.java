package pl.zut.adxl345;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import java.util.Locale;

/** Trzy płaszczyzny PCA: XY, XZ i YZ z łukiem kąta theta. */
public class VectorAngleView extends View {
    private final Paint grid=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint axis=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vector=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint reference=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arcPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint warning=new Paint(Paint.ANTI_ALIAS_FLAG);
    private volatile OscillationAnalyzer.DirectionResult result;

    public VectorAngleView(Context c){super(c);init();}
    public VectorAngleView(Context c,AttributeSet a){super(c,a);init();}
    public VectorAngleView(Context c,AttributeSet a,int s){super(c,a,s);init();}

    private void init(){
        setBackgroundColor(Color.WHITE);
        grid.setColor(0xFFE5E7EB); grid.setStrokeWidth(dp(1));
        axis.setColor(0xFF64748B); axis.setStrokeWidth(dp(1.2f));
        vector.setColor(0xFF1565C0); vector.setStrokeWidth(dp(3)); vector.setStrokeCap(Paint.Cap.ROUND);
        reference.setColor(0xFF94A3B8); reference.setStrokeWidth(dp(1.2f)); reference.setPathEffect(new android.graphics.DashPathEffect(new float[]{dp(6),dp(5)},0));
        arcPaint.setColor(0xFF00838F); arcPaint.setStyle(Paint.Style.STROKE); arcPaint.setStrokeWidth(dp(2.2f));
        text.setColor(0xFF0F172A); text.setTextSize(dp(13)); text.setFakeBoldText(true);
        warning.setColor(0xFFB45309); warning.setTextSize(dp(11)); warning.setFakeBoldText(true);
    }

    public void setDirection(OscillationAnalyzer.DirectionResult r){ result=r; postInvalidateOnAnimation(); }
    public void clear(){result=null;postInvalidate();}

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        int w=getWidth(),h=getHeight();
        if(w<=0||h<=0)return;
        OscillationAnalyzer.DirectionResult r=result;
        if(r==null){
            c.drawText("Brak wyraźnego kierunku PCA – uruchom drgania",dp(12),dp(28),text);
            return;
        }
        float panelH=h/3f;
        drawPlane(c,0,panelH,"XY","X","Y",r.dirX,r.dirY,r.angleXYDeg,r);
        drawPlane(c,panelH,panelH,"XZ","X","Z",r.dirX,r.dirZ,r.angleXZDeg,r);
        drawPlane(c,2*panelH,panelH,"YZ","Y","Z",r.dirY,r.dirZ,r.angleYZDeg,r);
    }

    private void drawPlane(Canvas c,float top0,float ph,String name,String ax1,String ax2,
                           double p1,double p2,double angle,OscillationAnalyzer.DirectionResult r){
        float pad=dp(18), titleH=dp(40), bottom=dp(12);
        float usableTop=top0+titleH, usableBottom=top0+ph-bottom;
        float size=Math.min(getWidth()-2*pad,usableBottom-usableTop);
        float cx=getWidth()/2f, cy=usableTop+size/2f;
        float rad=size*0.42f;

        c.drawText(String.format(Locale.US,"%s   θ%s = %+.1f°",name,name,angle),pad,top0+dp(24),text);
        String conf=String.format(Locale.US,"PCA %.0f%%",r.dominancePct);
        if(r.dominancePct<OscillationAnalyzer.DIRECTION_RELIABLE_PCT){
            c.drawText(conf+" – NISKA PEWNOŚĆ",getWidth()-dp(180),top0+dp(24),warning);
        }else{
            c.drawText(conf,getWidth()-dp(90),top0+dp(24),text);
        }

        for(int i=-2;i<=2;i++){
            float q=i*rad/2f;
            c.drawLine(cx-rad,cy+q,cx+rad,cy+q,grid);
            c.drawLine(cx+q,cy-rad,cx+q,cy+rad,grid);
        }
        c.drawLine(cx-rad,cy,cx+rad,cy,axis);
        c.drawLine(cx,cy-rad,cx,cy+rad,axis);
        c.drawText(ax1,cx+rad-dp(14),cy-dp(6),text);
        c.drawText(ax2,cx+dp(6),cy-rad+dp(16),text);

        double norm=Math.hypot(p1,p2);
        if(norm>1e-12){
            float vx=(float)(rad*0.88*p1/norm);
            float vy=(float)(-rad*0.88*p2/norm);
            c.drawLine(cx-vx,cy-vy,cx+vx,cy+vy,vector);
        }

        float rr=rad*0.46f;
        c.drawLine(cx,cy,cx+rr,cy,reference);
        RectF oval=new RectF(cx-rr,cy-rr,cx+rr,cy+rr);
        // Canvas: dodatni sweep zgodnie z ruchem wskazówek; matematyczne +angle idzie do góry.
        c.drawArc(oval,0f,(float)-angle,false,arcPaint);

        double mid=Math.toRadians(angle/2.0);
        float tx=cx+(float)(rr*1.28*Math.cos(mid));
        float ty=cy-(float)(rr*1.28*Math.sin(mid));
        c.drawText(String.format(Locale.US,"%+.1f°",angle),tx-dp(16),ty,text);

        if(top0+ph<h()-1) c.drawLine(dp(8),top0+ph-dp(1),getWidth()-dp(8),top0+ph-dp(1),grid);
    }

    private int h(){return getHeight();}
    private float dp(float v){return v*getResources().getDisplayMetrics().density;}
}

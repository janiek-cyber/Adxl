﻿ADXL345 PRO ANDROID V6.6 – EXCEL Z WYKRESAMI KIERUNKU
======================================================

Najważniejsza zmiana względem V6.5:
- XLSX ma teraz 3 arkusze:
  1. Podsumowanie
  2. Dane_1
  3. Kierunki

Arkusz „Kierunki” zawiera trzy wykresy:
- XY
- XZ
- YZ

Na każdym wykresie są:
- wektor / oś kierunku PCA,
- oś odniesienia 0°,
- łuk kąta theta,
- tytuł z wartością kąta i średnią dominacją PCA.

Kąty w Excelu są liczone jako średnia OSIOWA.
To jest ważne, ponieważ kierunek +u i -u oznacza tę samą oś drgań
i zwykła średnia arytmetyczna mogłaby być błędna przy przejściu przez ±90°.

Jeżeli nie ma żadnego wiarygodnego kierunku PCA (dominacja <55%),
wykres ma tytuł „brak wiarygodnego kierunku PCA”.

Pozostałe funkcje V6.5 pozostają:
- USB OTG / RP2040
- 400 Hz + T_us
- START zapisuje natychmiast
- STOP nie blokuje kolejnego START
- CSV/XLSX w tle
- FFT, amplituda i skok P-P
- jakość FFT >=60% dla wiarygodnego skoku
- PCA LIVE niezależne od FFT
- wykresy XY/XZ/YZ w aplikacji
- logo i splash

Wersja: 6.6
versionCode: 66

Wykresy kierunku mają zbliżone proporcje 1:1, aby kąt nie był wizualnie zniekształcony przez prostokątny obszar wykresu.

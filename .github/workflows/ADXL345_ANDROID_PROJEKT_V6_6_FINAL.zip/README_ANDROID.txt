ADXL345 – SKOK OSCYLACJI + EXCEL – ANDROID
============================================

Wersja Android przygotowana na bazie rejestratora PC.

CO ROBI APLIKACJA
-----------------
- połączenie z urządzeniem przez USB-OTG / USB-Serial,
- obsługa typowych układów FTDI, CP210x, CH340/CH341, Prolific i CDC/ACM,
- odczyt X/Y/Z,
- kalibracja spoczynku 2 s po START,
- opcjonalna auto-kalibracja 1 g,
- filtr Kalmana do prezentacji i detekcji ruchu,
- wykres X/Y/Z/|a| na żywo,
- automatyczne wykrycie ruchu i zapis,
- bufor próbek sprzed wyzwolenia,
- automatyczne wyznaczanie dominującego kierunku drgań,
- częstotliwość [Hz],
- amplituda przyspieszenia [g],
- amplituda przemieszczenia [mm],
- pełny SKOK P-P [mm],
- jakość dopasowania [%],
- rzeczywista częstotliwość próbkowania [Hz],
- zapis CSV + XLSX (Excel).

WAŻNE – JAK PODŁĄCZYĆ
---------------------
Sam moduł ADXL345 jest czujnikiem I2C/SPI i NIE podłącza się bezpośrednio do USB telefonu.
Wymagany jest ten sam układ pośredniczący, który na komputerze tworzył port COM
(np. Arduino / ESP / konwerter USB-Serial / mikrokontroler) i wysyłał linie X/Y/Z.
Telefon musi obsługiwać USB Host / OTG.

Akceptowane przykładowe formaty wejściowe:
  0.012,-0.034,1.005
  0,012;-0,034;1,005
  X:0.012 Y:-0.034 Z:1.005
  X=0.012, Y=-0.034, Z=1.005

DOMYŚLNE USTAWIENIA
-------------------
Baud:                 115200
Próg ruchu:           0.08 g
Skala g/jedn.:        1.0
Pretrigger:            2.0 s
f min:                 0.5 Hz
f max:                 50.0 Hz
Okno analizy:          6.0 s
Filtr Kalmana:         ON
Auto-kalibracja 1 g:   ON

POMIAR SKOKU
------------
Skok jest liczony z ruchu okresowego, a nie przez proste podwójne całkowanie.
Algorytm:
1. usuwa offset i liniowy dryft z osi X/Y/Z,
2. PCA wyznacza dominujący kierunek drgań niezależnie od ustawienia czujnika,
3. przeszukuje częstotliwość na rzeczywistych znacznikach czasu,
4. dopasowuje sinus/cosinus,
5. wyznacza amplitudę przyspieszenia,
6. liczy:

   amplituda = a_peak / (2*pi*f)^2
   SKOK P-P  = 2 * amplituda

Dane do skoku są pobierane PRZED filtrem Kalmana, aby filtr nie zaniżał amplitudy.
Wynik jest przeznaczony dla ruchu okresowego / oscylacyjnego.
Nie jest to pomiar absolutnej drogi dla jednorazowego przesunięcia i zatrzymania.

EXCEL
-----
Po wykryciu ruchu aplikacja rozpoczyna zapis. Po STOP tworzy:
  ADXL345_yyyy-MM-dd_HH-mm-ss-SSS.csv
  ADXL345_yyyy-MM-dd_HH-mm-ss-SSS.xlsx

Android 10 i nowszy:
  Dokumenty/ADXL345/

W Excelu:
- arkusz "Podsumowanie"
- arkusz "Dane_1"

Kolumny Dane_1:
  czas_iso
  czas_od_startu_s
  X_g
  Y_g
  Z_g
  modul_g
  delta_od_spoczynku_g
  czestotliwosc_Hz
  amplituda_przyspieszenia_g
  amplituda_przemieszczenia_mm
  skok_PP_mm
  jakosc_proc
  probkowanie_Hz

W podsumowaniu skok statystyczny jest liczony dla wyników o jakości >= 50%.

JAK ZBUDOWAĆ APK
----------------
Projekt jest przygotowany do otwarcia w Android Studio.

1. Zainstaluj aktualne Android Studio.
2. Otwórz folder ADXL345_Android jako projekt.
3. Pozwól Android Studio wykonać Gradle Sync i pobrać zależności.
4. Jeżeli IDE zapyta o Android SDK 35, zainstaluj je z SDK Manager.
5. Build -> Build App Bundle(s) / APK(s) -> Build APK(s).
6. APK debug będzie w:
   app/build/outputs/apk/debug/app-debug.apk
7. Skopiuj APK na telefon i zainstaluj.

Projekt:
- minSdk 26 (Android 8.0)
- targetSdk 35
- Java 17
- zewnętrzna biblioteka USB: com.github.mik3y:usb-serial-for-android:3.11.0
- Excel XLSX jest generowany własnym lekkim generatorem OOXML, bez Apache POI.

OBSŁUGA NA TELEFONIE
--------------------
1. Podłącz urządzenie do telefonu przez adapter USB-OTG.
2. Uruchom aplikację.
3. Kliknij Odśwież.
4. Wybierz wykryty port USB.
5. Ustaw baud (zwykle 115200).
6. Kliknij Połącz i zaakceptuj zgodę Androida na USB.
7. Kliknij START.
8. Przez 2 s nie poruszaj czujnikiem.
9. Po komunikacie "KALIBRACJA OK" uruchom oscylacje.
10. Po pomiarze kliknij STOP.
11. Otwórz Dokumenty/ADXL345 i plik XLSX.

UWAGI PRAKTYCZNE
----------------
- Czujnik musi być sztywno przymocowany do poruszającego się elementu.
- Dla niskich częstotliwości zwiększ "Okno analizy" (np. 10–15 s).
- f max powinno być wyraźnie niższe niż połowa rzeczywistego próbkowania.
- Jeśli "Jakość" jest mała, wynik skoku może być niewiarygodny.
- Telefon utrzymuje ekran włączony podczas aktywnego pomiaru.

============================================================
BUILD ONLINE — GITHUB + CODEMAGIC
============================================================
W tej wersji projektu dodano plik codemagic.yaml do automatycznego budowania app-debug.apk online.
Dokładna instrukcja: README_GITHUB_CODEMAGIC.md
Dodatkowo można użyć GitHub Actions: Actions -> Build Android APK -> Run workflow.
